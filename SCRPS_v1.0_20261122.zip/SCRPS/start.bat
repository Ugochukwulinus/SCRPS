@echo off
cd /d "%~dp0"
call venv\Scripts\activate
echo Starting SCRPS offline... open http://127.0.0.1:5000 in your browser
waitress-serve --listen=127.0.0.1:5000 run:app
pause