"""Generates SCRPS raster icons offline (no third-party packages).

Run:  python make_icons.py
Writes: app/static/img/favicon-32.png
        app/static/img/apple-touch-icon.png
        app/static/img/favicon.ico   (16 / 32 / 48)
"""
import math
import os
import struct
import zlib

BLUE = (37, 99, 235)
MID = (29, 78, 216)
TEAL = (13, 148, 136)
GREEN = (22, 163, 74)
AMBER = (245, 158, 11)
WHITE = (255, 255, 255)
LIGHT = (242, 246, 252)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app", "static", "img")


def lerp(a, b, t):
    t = 0.0 if t < 0 else (1.0 if t > 1 else t)
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def sd_box(x, y, cx, cy, hx, hy, r):
    qx = abs(x - cx) - hx + r
    qy = abs(y - cy) - hy + r
    return math.hypot(max(qx, 0.0), max(qy, 0.0)) + min(max(qx, qy), 0.0) - r


def dist_seg(px, py, ax, ay, bx, by):
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    length = vx * vx + vy * vy
    t = 0.0 if length == 0 else max(0.0, min(1.0, (wx * vx + wy * vy) / length))
    return math.hypot(px - (ax + vx * t), py - (ay + vy * t))


def sample(x, y, background):
    if sd_box(x, y, .5, .5, .5, .5, .219) > 0:
        return background + (255,) if background else (0, 0, 0, 0)

    t = (x + y) * .5
    col = lerp(BLUE, MID, t * 2) if t < .5 else lerp(MID, TEAL, (t - .5) * 2)
    sheen = max(0.0, 1.0 - math.hypot(x - .16, y - .10) / .88) * .30
    col = lerp(col, WHITE, sheen)

    if y >= .469 and sd_box(x, y, .5, .547, .172, .109, .078) <= 0:
        col = lerp(col, WHITE, .92)
    if abs(x - .5) / .359 + abs(y - .375) / .172 <= 1:
        col = WHITE

    if dist_seg(x, y, .211, .384, .211, .516) <= .0234:
        col = AMBER
    if math.hypot(x - .211, y - .553) <= .05:
        col = AMBER

    badge = math.hypot(x - .719, y - .719)
    if badge <= .203:
        col = WHITE
    if badge <= .166:
        col = GREEN
        if (dist_seg(x, y, .644, .725, .697, .778) <= .025 or
                dist_seg(x, y, .697, .778, .803, .650) <= .025):
            col = WHITE
    return col + (255,)


def render(size, ss=3, background=None):
    raw = bytearray()
    step = 1.0 / (size * ss)
    n = ss * ss
    for py in range(size):
        raw.append(0)
        for px in range(size):
            r = g = b = a = 0
            for sy in range(ss):
                Y = (py * ss + sy + .5) * step
                for sx in range(ss):
                    X = (px * ss + sx + .5) * step
                    c = sample(X, Y, background)
                    alpha = c[3]
                    r += c[0] * alpha
                    g += c[1] * alpha
                    b += c[2] * alpha
                    a += alpha
            if a:
                raw += bytes((r // a, g // a, b // a, a // n))
            else:
                raw += bytes(4)
    return bytes(raw)


def chunk(tag, data):
    return (struct.pack(">I", len(data)) + tag + data +
            struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def png_bytes(size, raw):
    header = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) +
            chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def write(path, data):
    with open(path, "wb") as handle:
        handle.write(data)
    print(f"  {os.path.relpath(path, os.path.dirname(OUT))}  ({len(data):,} bytes)")


def main():
    os.makedirs(OUT, exist_ok=True)
    print("Rendering SCRPS icons...")
    cache = {}
    for size in (16, 32, 48):
        cache[size] = png_bytes(size, render(size, ss=4))
    cache[180] = png_bytes(180, render(180, ss=3, background=LIGHT))

    write(os.path.join(OUT, "favicon-32.png"), cache[32])
    write(os.path.join(OUT, "apple-touch-icon.png"), cache[180])

    images = [cache[s] for s in (16, 32, 48)]
    header = struct.pack("<HHH", 0, 1, len(images))
    offset = 6 + 16 * len(images)
    entries = payload = b""
    for size, data in zip((16, 32, 48), images):
        entries += struct.pack("<BBBBHHII", size, size, 0, 0, 1, 32, len(data), offset)
        payload += data
        offset += len(data)
    write(os.path.join(OUT, "favicon.ico"), header + entries + payload)
    print("Done.")


if __name__ == "__main__":
    main()