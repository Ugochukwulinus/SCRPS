# SCRPS — Student Course Registration & Result Processing System

Offline web application for course registration, fee payment, result processing and
transcript generation in a tertiary institution.

**Stack:** Python (Flask) · HTML · CSS · JavaScript · SQLite · ReportLab
**Internet:** needed once for installation only. Runs fully offline afterwards.
**Delivery state:** empty database — all institutional data is entered through the interface.

---

## 1. Features

| Module | Capability |
|---|---|
| Accounts | First-time admin setup, student self sign-up with auto-generated matric number, staff provisioning, login, password change, role-based access |
| Academic setup | Faculties, departments, programmes, courses with prerequisites, curricula versioned by entry year |
| Sessions | Two semesters per session, current-session flag, registration windows, one-click rollover that copies course allocations |
| Fees & payments | Fee schedule per session/programme/level, automatic invoice, online checkout (card/transfer/USSD), instant clearance, PDF receipt, bursary oversight |
| Registration | Rule-validated selection, one-click auto-selection, add/drop, submission, adviser approval/rejection, PDF course form |
| Results | Lecturer CA/exam entry, CSV bulk import, submission, HOD broadsheet review, approval and locking, return-with-reason |
| Processing | Automatic grades, GPA, CGPA (best attempt), carryovers, degree classification, session processing and level promotion |
| Documents | Course form, result slip, transcript, broadsheet, payment receipt — all generated locally as PDF |
| Oversight | In-app notifications, settings, grading scale editor, registrations report, full audit log |

---

## 2. System Requirements

| Item | Requirement |
|---|---|
| Operating system | Windows 10/11, macOS 11+, or modern Linux |
| Python | 3.10 or newer (3.11/3.12 recommended, 64-bit) |
| RAM | 2 GB minimum, 4 GB recommended |
| Disk space | 500 MB free |
| Browser | Chrome, Edge, Firefox or Safari (current) |
| Internet | Only during installation |

Check Python: `python --version` (Windows) or `python3 --version` (macOS/Linux).
Install from https://www.python.org/downloads/ if missing.
**Windows: tick "Add python.exe to PATH" during installation.**

---

## 3. Installation (one time)

Open a terminal in the project folder. The `venv` folder is not shipped — create it once.

**Windows (PowerShell)**
```powershell
python -m venv venv
venv\Scripts\activate
pip install --no-index --find-links=wheels -r requirements.txt
```

**macOS / Linux**
```bash
python3 -m venv venv
source venv/bin/activate
pip install --no-index --find-links=wheels -r requirements.txt
```

The commands above install **offline** from the supplied `wheels/` folder.
If `wheels/` is absent or you prefer fresh packages, use:
```bash
pip install --timeout 120 --retries 10 -r requirements.txt
```
If that times out, run it again — it resumes from cache.

---

## 4. Running

The virtual environment must be active (prompt starts with `(venv)`).

| Purpose | Windows | macOS / Linux |
|---|---|---|
| Development | `python run.py` | `python run.py` |
| Presentation | double-click `start.bat` | `waitress-serve --listen=127.0.0.1:5000 run:app` |

Open **http://127.0.0.1:5000** · stop with `Ctrl + C`.
`127.0.0.1` is the computer itself — no network is involved.

---

## 5. First-Time Configuration

The database is empty on delivery. First launch opens **First-time setup**; create the
administrator there (or run `python create_admin.py`). Then configure in this order:

| # | Section | Enter |
|---|---|---|
| 1 | Grading | Grade bands, e.g. A 70–100 (5), B 60–69 (4), C 50–59 (3), D 45–49 (2), E 40–44 (1), F 0–39 (0, fail) |
| 2 | Settings | CA/exam maxima, unit limits, pass mark, promotion units, sign-up switch |
| 3 | Faculties | Institutional faculties/schools |
| 4 | Departments | Departments under each faculty |
| 5 | Programmes | Programmes under each department |
| 6 | Courses | Code, title, units, department, prerequisites |
| 7 | Curricula | One version per entry year; add courses with level and semester |
| 8 | Sessions | Create session, mark current, open a registration window |
| 9 | Fee Schedule | Amount per session + programme + level ("All levels" allowed) |
| 10 | Staff | Lecturers, course advisers, HOD |
| 11 | Bursary | Bursary officer accounts |
| 12 | Advisers | Assign a staff member to each programme + level |
| 13 | Allocations | Assign each course to its lecturer for the semester |
| 14 | Students | Students self sign-up, or admin creates them |

Enter a full semester of courses so registered units can reach the minimum (default 15).
The grading scale is empty on delivery — results cannot be graded until it is entered.

---

## 6. Roles

| Role | Created by | Permissions |
|---|---|---|
| Admin | First-time setup / `create_admin.py` | Configuration and oversight |
| HOD / Exams | Admin → Staff | Approve and lock results, return results, broadsheets, session processing |
| Course Adviser | Admin → Staff, then Admin → Advisers | Approve registrations for assigned levels; enter own course scores |
| Lecturer | Admin → Staff | Enter and submit scores for allocated courses |
| Bursary | Admin → Bursary | View all transactions and receipts |
| Student | Self sign-up (or Admin → Students) | Pay fees, register courses, view results, download documents |

Adviser rights follow the **Advisers assignment**: any lecturer assigned to a level gains the
adviser interface for that level only.

---

## 7. Workflows

**Fees:** Student → Payments → Pay → choose method → payment confirmed → fees cleared
automatically → receipt issued → registration unlocked.

**Registration:** Student selects courses (or auto-select) → Submit → Adviser approves or
rejects with a reason → approved student downloads the course form.

**Results:** Lecturer enters scores manually or by CSV import → Submit → HOD reviews the
broadsheet → Approve and lock (or return with a reason) → student sees grades, GPA, CGPA and
downloads the slip and transcript.

**Session end:** HOD → Session Processing → review computed standing → apply decisions →
levels update and students are notified. Admin → Sessions → Roll over creates the next
session and copies allocations.

---

## 8. Testing

```bash
python -m unittest discover tests   # academic rule unit tests
python load_test.py                 # 120 concurrent registrations, separate database
```

Neither test touches `scrps.db`.

### Verification checklist

| # | Role | Action | Expected |
|---|---|---|---|
| 1 | Admin | Configure grading, settings, faculty → department → programme → courses → curriculum | Records listed |
| 2 | Admin | Create session, mark current, open Semester 1, set fee schedule | Window open, fee listed |
| 3 | Admin | Create lecturer, adviser, HOD, bursary; assign adviser; allocate courses | Assignments listed |
| 4 | — | Student sign-up | Matric number generated, signed in |
| 5 | Student | Open registration before paying | Courses blocked with fee reason |
| 6 | Student | Payments → pay | Confirmed, receipt issued, fees cleared |
| 7 | Student | Try dependent course before its prerequisite | Blocked: unmet prerequisite |
| 8 | Student | Add prerequisite then dependent course | Both added |
| 9 | Student | Add same course again / Semester-2 course | Blocked: duplicate / semester mismatch |
| 10 | Student | Auto-select, then submit | Eligible courses added; awaiting approval |
| 11 | Adviser | Review queue → approve | Approved, student notified |
| 12 | Adviser | Open a registration outside assigned level | 403 |
| 13 | Student | Download course form | PDF with courses and signature lines |
| 14 | Lecturer | Enter CA above maximum | Rejected with range message |
| 15 | Lecturer | CSV template → import valid file | Scores saved as draft |
| 16 | Lecturer | Import file with one invalid row | Nothing saved, line errors listed |
| 17 | Lecturer | Submit to HOD | Locked for lecturer |
| 18 | HOD | Return with reason, then approve and lock | Lecturer sees reason; results immutable |
| 19 | HOD | Download broadsheet | PDF with entries and pass rate |
| 20 | Student | View results, download slip and transcript | GPA, CGPA, classification, carryovers correct |
| 21 | HOD | Session processing → apply | Levels updated, students notified |
| 22 | Admin | Sessions → roll over | Next session created, allocations copied |
| 23 | Bursary | Transactions | Payment listed with correct total |
| 24 | Admin | Audit log | Full chain attributed to real accounts |
| 25 | — | Disable Wi-Fi, refresh, download a PDF | Everything still works |

---

## 9. Database Management

| Task | Action |
|---|---|
| Reset everything | Stop server → delete `scrps.db`, `scrps.db-wal`, `scrps.db-shm` → restart |
| Forgot admin password | `python create_admin.py` (same username resets it) |
| Add another admin | `python create_admin.py` with a new username |
| Backup | Stop server, copy `scrps.db*` into a `backup/` folder |
| Restore | Replace `scrps.db*` with the backup, restart |

Take a backup once configuration is complete — restoring it is faster than re-entering data.
Schema upgrades are applied automatically at startup; new columns are added without data loss.

---

## 10. Offline Guarantee

- No CDN links, external fonts or online APIs.
- Single-file SQLite database; no database server required.
- All PDFs generated locally with ReportLab.
- Payment gateway runs in offline sandbox mode (`app/payments/gateway.py`).
- Icons are local; `python make_icons.py` regenerates them without internet.
- Server binds to the local machine only.

---

## 11. Project Structure

```
SCRPS/
├── requirements.txt      # Pinned Python packages
├── config.py             # Database path, secret key, gateway mode
├── run.py                # Development server
├── start.bat             # Presentation launcher (Windows)
├── create_admin.py       # Administrator creation / password recovery
├── load_test.py          # Concurrency load test
├── make_icons.py         # Regenerates icon assets offline
├── README.md
├── wheels/               # Offline installation packages
├── tests/
│   └── test_rules.py     # Unit tests
└── app/
    ├── __init__.py       # App factory, schema upgrade, navigation context
    ├── models.py         # Schema, grading/GPA engine, helpers
    ├── main.py           # Role dashboards
    ├── menu.py           # Role navigation
    ├── notifications.py  # Notification inbox
    ├── auth/             # Setup, login, sign-up, password, permissions
    ├── admin/            # Faculties → audit log, fee schedule
    ├── registration/     # Rule engine, selection, approval, course form PDF
    ├── results/          # Score entry, CSV import, HOD review, processing, PDFs
    ├── payments/         # Invoice, checkout, gateway adapter, receipts
    ├── templates/        # HTML pages
    └── static/           # Stylesheet and icon assets
```

---

## 12. Presentation Outline (≈12 minutes)

1. Turn Wi-Fi off and refresh — the system keeps working.
2. Admin: faculties, departments, courses with prerequisites, curriculum version, session
   window, fee schedule, staff, advisers, allocations.
3. Student: sign up (show generated matric number), pay fees, show receipt and cleared status.
4. Student: show a blocked course and its reason, use auto-select, submit.
5. Adviser: review queue, approve. Mention level scoping.
6. Student: download the course form.
7. Lecturer: CSV template, bulk import, show a rejected row, correct it, submit.
8. HOD: broadsheet, return with a reason, re-submit, approve and lock, download broadsheet.
9. Student: results, GPA/CGPA/classification, slip and transcript.
10. HOD: session processing decisions. Admin: audit log and transactions.

---

## 13. Security

- Passwords hashed (Werkzeug); never stored in plaintext.
- CSRF protection on every form.
- Server-side role and level scoping on protected routes.
- Approved results are immutable; corrections use the HOD return flow.
- Every significant action is written to the audit log.

**Before real deployment:** set a unique `SECRET_KEY` in `config.py`, serve over HTTPS with a
production WSGI server, and implement a live provider in `app/payments/gateway.py` with
server-side transaction verification.

---

## 14. Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'flask'` | Activate the venv first |
| `pip` times out | Re-run the command, or install offline from `wheels/` |
| Port 5000 in use | Close the other program or change the port in `run.py` |
| 403 page | The logged-in role cannot open that URL |
| Grades show "—" | Grading scale not configured (Admin → Grading) |
| Student cannot submit | Units below minimum, or no adviser assigned to that level |
| Lecturer sees no students | No allocation, or registrations not yet approved |
| Registration blocked | Fees unpaid, prerequisite unmet, unit cap, or wrong semester |
| Forgot admin password | `python create_admin.py` |

---

## 15. Limitations & Future Work

- Payment gateway operates in sandbox mode; a live provider is required for real funds.
- In-app notifications only; SMS/email integration is future work.
- Graduation eligibility is reported; certificate generation is future work.
- Single-institution deployment; multi-campus federation is future work.