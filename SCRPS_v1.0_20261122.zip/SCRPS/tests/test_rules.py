"""Unit tests for the academic rule engine. Run: python -m unittest discover tests"""
import os
import tempfile
import unittest
from config import Config
from app import create_app
from app.models import (db, User, Student, Faculty, Department, Programme, Course,
                        Curriculum, CurriculumItem, Session, Semester, FeeClearance,
                        Registration, RegistrationCourse, Result, GradeScale, Setting,
                        student_cgpa, carryovers)
from app.registration.validation import validate_add, validate_submission


class TestConfig(Config):
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(tempfile.mkdtemp(), "rules.db")
    WTF_CSRF_ENABLED = False


def build():
    for letter, lo, hi, pts, ok in [("A", 70, 100, 5, True), ("B", 60, 69, 4, True),
                                    ("C", 50, 59, 3, True), ("D", 45, 49, 2, True),
                                    ("E", 40, 44, 1, True), ("F", 0, 39, 0, False)]:
        db.session.add(GradeScale(letter=letter, min_score=lo, max_score=hi,
                                  points=pts, is_pass=ok))
    fac = Faculty(code="SCI", name="Science")
    db.session.add(fac); db.session.flush()
    dept = Department(code="CSC", name="Computer Science", faculty_id=fac.id)
    db.session.add(dept); db.session.flush()
    prog = Programme(code="CSC", name="B.Sc Computer Science", department_id=dept.id)
    db.session.add(prog); db.session.flush()
    c1 = Course(code="CSC101", title="Intro to Computing", units=3, department_id=dept.id)
    c2 = Course(code="CSC102", title="Intro to Computing II", units=3, department_id=dept.id)
    c3 = Course(code="CSC103", title="Programming", units=3, department_id=dept.id)
    db.session.add_all([c1, c2, c3]); db.session.flush()
    c2.prereqs.append(c1)
    cur = Curriculum(programme_id=prog.id, entry_year=2026)
    db.session.add(cur); db.session.flush()
    for c in (c1, c2, c3):
        db.session.add(CurriculumItem(curriculum_id=cur.id, course_id=c.id,
                                      level=100, semester=1))
    sess = Session(name="2026/2027", is_current=True)
    db.session.add(sess); db.session.flush()
    sem = Semester(session_id=sess.id, number=1, registration_open=True)
    db.session.add(sem); db.session.flush()
    u = User(username="S1", full_name="Test Student", role="student")
    u.set_password("pass1234")
    db.session.add(u); db.session.flush()
    st = Student(user_id=u.id, matric_no="S1", programme_id=prog.id,
                 entry_year=2026, level=100)
    db.session.add(st); db.session.flush()
    db.session.add(FeeClearance(student_id=st.id, session_id=sess.id))
    db.session.commit()
    return {"c1": c1, "c2": c2, "c3": c3, "st": st, "sem": sem, "sess": sess}


def reg_for(w):
    r = Registration.query.filter_by(student_id=w["st"].id,
                                     semester_id=w["sem"].id).first()
    if not r:
        r = Registration(student_id=w["st"].id, semester_id=w["sem"].id, status="draft")
        db.session.add(r); db.session.commit()
    return r


def add(w, c):
    r = reg_for(w)
    db.session.add(RegistrationCourse(registration_id=r.id, course_id=c.id))
    db.session.commit()
    return r


def approved(w, c, ca, ex, reg):
    rc = RegistrationCourse.query.filter_by(registration_id=reg.id,
                                            course_id=c.id).first()
    if not rc:
        rc = RegistrationCourse(registration_id=reg.id, course_id=c.id)
        db.session.add(rc); db.session.flush()
    r = Result(registration_course_id=rc.id, ca_score=ca, exam_score=ex,
               status="approved")
    r.recompute()
    db.session.add(r); db.session.commit()
    return r


class RulesTest(unittest.TestCase):
    def setUp(self):
        self.app = create_app(TestConfig)
        self.ctx = self.app.app_context()
        self.ctx.push()
        db.drop_all(); db.create_all()
        self.w = build()

    def tearDown(self):
        db.session.remove(); db.drop_all(); self.ctx.pop()

    def test_grade_boundaries(self):
        self.assertEqual(GradeScale.grade_for(70).letter, "A")
        self.assertEqual(GradeScale.grade_for(69).letter, "B")
        self.assertEqual(GradeScale.grade_for(40).letter, "E")
        self.assertEqual(GradeScale.grade_for(39).letter, "F")

    def test_recompute(self):
        r = Result(ca_score=25, exam_score=40)
        r.recompute()
        self.assertEqual((r.total, r.grade, r.points), (65, "B", 4))

    def test_duplicate_blocked(self):
        add(self.w, self.w["c1"])
        ok, issues = validate_add(self.w["st"], self.w["c1"], self.w["sem"],
                                  reg_for(self.w))
        self.assertFalse(ok)
        self.assertTrue(any("already in your selection" in m for _, m in issues))

    def test_prerequisite_then_coregistration(self):
        ok, _ = validate_add(self.w["st"], self.w["c2"], self.w["sem"], None)
        self.assertFalse(ok)
        add(self.w, self.w["c1"])
        ok, _ = validate_add(self.w["st"], self.w["c2"], self.w["sem"],
                             reg_for(self.w))
        self.assertTrue(ok)

    def test_fees_gate(self):
        FeeClearance.query.delete(); db.session.commit()
        ok, issues = validate_add(self.w["st"], self.w["c1"], self.w["sem"], None)
        self.assertFalse(ok)
        self.assertTrue(any("fees" in m.lower() for _, m in issues))

    def test_passed_course_blocked(self):
        approved(self.w, self.w["c1"], 25, 40, reg_for(self.w))
        ok, issues = validate_add(self.w["st"], self.w["c1"], self.w["sem"],
                                  reg_for(self.w))
        self.assertFalse(ok)
        self.assertTrue(any("already been passed" in m for _, m in issues))

    def test_unit_cap(self):
        db.session.add(Setting(key="max_units", value="4")); db.session.commit()
        add(self.w, self.w["c1"])
        ok, _ = validate_add(self.w["st"], self.w["c2"], self.w["sem"],
                             reg_for(self.w))
        self.assertFalse(ok)

    def test_min_units_on_submit(self):
        add(self.w, self.w["c1"])
        self.assertTrue(validate_submission(self.w["st"], reg_for(self.w)))

    def test_carryover_listed(self):
        approved(self.w, self.w["c1"], 10, 20, reg_for(self.w))
        self.assertEqual([c.code for c in carryovers(self.w["st"])], ["CSC101"])

    def test_cgpa_best_attempt(self):
        approved(self.w, self.w["c1"], 10, 20, reg_for(self.w))
        sem2 = Semester(session_id=self.w["sess"].id, number=2)
        db.session.add(sem2); db.session.flush()
        reg2 = Registration(student_id=self.w["st"].id, semester_id=sem2.id,
                            status="approved")
        db.session.add(reg2); db.session.flush()
        approved(self.w, self.w["c1"], 25, 40, reg2)
        self.assertEqual(student_cgpa(self.w["st"]), 4.0)
        self.assertEqual(carryovers(self.w["st"]), [])


if __name__ == "__main__":
    unittest.main()