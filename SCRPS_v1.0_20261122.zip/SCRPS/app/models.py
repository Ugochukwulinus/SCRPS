"""SCRPS schema — single source of truth."""
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()
ROLES = ("student", "lecturer", "adviser", "hod", "bursary", "admin")


class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship("Student", backref="user", uselist=False)
    lecturer = db.relationship("Lecturer", backref="user", uselist=False)

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)

    @property
    def is_active(self):
        return self.active


class Setting(db.Model):
    __tablename__ = "settings"
    key = db.Column(db.String(50), primary_key=True)
    value = db.Column(db.String(100), nullable=False)

    @staticmethod
    def get(key, default=None):
        row = db.session.get(Setting, key)
        return row.value if row else default

    @staticmethod
    def get_int(key, default=0):
        try:
            return int(Setting.get(key, default))
        except (TypeError, ValueError):
            return default


class GradeScale(db.Model):
    __tablename__ = "grade_scales"
    id = db.Column(db.Integer, primary_key=True)
    letter = db.Column(db.String(2), unique=True, nullable=False)
    min_score = db.Column(db.Integer, nullable=False)
    max_score = db.Column(db.Integer, nullable=False)
    points = db.Column(db.Integer, nullable=False)
    is_pass = db.Column(db.Boolean, default=True, nullable=False)

    @staticmethod
    def grade_for(total):
        return GradeScale.query.filter(
            GradeScale.min_score <= total, GradeScale.max_score >= total).first()


class Faculty(db.Model):
    __tablename__ = "faculties"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(10), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)


class Department(db.Model):
    __tablename__ = "departments"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(10), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    faculty_id = db.Column(db.Integer, db.ForeignKey("faculties.id"), nullable=False)
    faculty = db.relationship("Faculty", backref="departments")


class Programme(db.Model):
    __tablename__ = "programmes"
    id = db.Column(db.Integer, primary_key=True)
    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"), nullable=False)
    code = db.Column(db.String(10), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    duration_years = db.Column(db.Integer, default=4, nullable=False)
    department = db.relationship("Department", backref="programmes")


prerequisites = db.Table(
    "course_prerequisites",
    db.Column("course_id", db.Integer, db.ForeignKey("courses.id"), primary_key=True),
    db.Column("prerequisite_id", db.Integer, db.ForeignKey("courses.id"), primary_key=True),
)


class Course(db.Model):
    __tablename__ = "courses"
    __table_args__ = (db.CheckConstraint("units > 0", name="ck_course_units"),)
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(10), unique=True, nullable=False, index=True)
    title = db.Column(db.String(150), nullable=False)
    units = db.Column(db.Integer, nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"), nullable=False)
    department = db.relationship("Department", backref="courses")
    prereqs = db.relationship(
        "Course", secondary=prerequisites,
        primaryjoin="Course.id == course_prerequisites.c.course_id",
        secondaryjoin="Course.id == course_prerequisites.c.prerequisite_id",
        backref="required_for")


class Curriculum(db.Model):
    __tablename__ = "curricula"
    __table_args__ = (db.UniqueConstraint("programme_id", "entry_year"),)
    id = db.Column(db.Integer, primary_key=True)
    programme_id = db.Column(db.Integer, db.ForeignKey("programmes.id"), nullable=False)
    entry_year = db.Column(db.Integer, nullable=False)
    label = db.Column(db.String(100), default="")
    programme = db.relationship("Programme", backref="curricula")
    items = db.relationship("CurriculumItem", backref="curriculum",
                            cascade="all, delete-orphan")


class CurriculumItem(db.Model):
    __tablename__ = "curriculum_items"
    __table_args__ = (db.UniqueConstraint("curriculum_id", "course_id"),)
    id = db.Column(db.Integer, primary_key=True)
    curriculum_id = db.Column(db.Integer, db.ForeignKey("curricula.id"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    level = db.Column(db.Integer, nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    requirement = db.Column(db.String(10), default="core", nullable=False)
    course = db.relationship("Course")


class Session(db.Model):
    __tablename__ = "sessions"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True, nullable=False)
    is_current = db.Column(db.Boolean, default=False, nullable=False)


class Semester(db.Model):
    __tablename__ = "semesters"
    __table_args__ = (db.UniqueConstraint("session_id", "number"),)
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("sessions.id"), nullable=False)
    number = db.Column(db.Integer, nullable=False)
    registration_open = db.Column(db.Boolean, default=False, nullable=False)
    session = db.relationship("Session", backref="semesters")

    @property
    def label(self):
        return f"{self.session.name} · Semester {self.number}"


class Student(db.Model):
    __tablename__ = "students"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    matric_no = db.Column(db.String(30), unique=True, nullable=False, index=True)
    programme_id = db.Column(db.Integer, db.ForeignKey("programmes.id"), nullable=False)
    entry_year = db.Column(db.Integer, nullable=False)
    level = db.Column(db.Integer, default=100, nullable=False)
    programme = db.relationship("Programme", backref="students")

    def curriculum(self):
        return (Curriculum.query
                .filter(Curriculum.programme_id == self.programme_id,
                        Curriculum.entry_year <= self.entry_year)
                .order_by(Curriculum.entry_year.desc()).first())


class Lecturer(db.Model):
    __tablename__ = "lecturers"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    staff_no = db.Column(db.String(20), unique=True, nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"), nullable=False)
    department = db.relationship("Department", backref="lecturers")


class LevelAdviser(db.Model):
    __tablename__ = "level_advisers"
    __table_args__ = (db.UniqueConstraint("programme_id", "level"),)
    id = db.Column(db.Integer, primary_key=True)
    lecturer_id = db.Column(db.Integer, db.ForeignKey("lecturers.id"), nullable=False)
    programme_id = db.Column(db.Integer, db.ForeignKey("programmes.id"), nullable=False)
    level = db.Column(db.Integer, nullable=False)
    lecturer = db.relationship("Lecturer", backref="adviser_roles")
    programme = db.relationship("Programme", backref="level_advisers")


class CourseAllocation(db.Model):
    __tablename__ = "course_allocations"
    __table_args__ = (db.UniqueConstraint("course_id", "semester_id"),)
    id = db.Column(db.Integer, primary_key=True)
    lecturer_id = db.Column(db.Integer, db.ForeignKey("lecturers.id"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    semester_id = db.Column(db.Integer, db.ForeignKey("semesters.id"), nullable=False)
    lecturer = db.relationship("Lecturer", backref="allocations")
    course = db.relationship("Course")
    semester = db.relationship("Semester")


class FeeSchedule(db.Model):
    """Institution-set fees: per session + programme + level (level 0 = all levels)."""
    __tablename__ = "fee_schedules"
    __table_args__ = (db.UniqueConstraint("session_id", "programme_id", "level"),)
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("sessions.id"), nullable=False)
    programme_id = db.Column(db.Integer, db.ForeignKey("programmes.id"), nullable=False)
    level = db.Column(db.Integer, default=0, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    session = db.relationship("Session")
    programme = db.relationship("Programme")


class FeeClearance(db.Model):
    __tablename__ = "fee_clearances"
    __table_args__ = (db.UniqueConstraint("student_id", "session_id"),)
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id"), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey("sessions.id"), nullable=False)
    cleared_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    cleared_at = db.Column(db.DateTime, default=datetime.utcnow)


class Payment(db.Model):
    __tablename__ = "payments"
    __table_args__ = (db.UniqueConstraint("student_id", "session_id"),)
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id"), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey("sessions.id"), nullable=False)
    invoice_no = db.Column(db.String(40), unique=True, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(12), default="pending", nullable=False)
    method = db.Column(db.String(20), default="")
    gateway_ref = db.Column(db.String(60), default="")
    paid_at = db.Column(db.DateTime)
    teller_ref = db.Column(db.String(60), default="")
    note = db.Column(db.String(255), default="")
    reject_reason = db.Column(db.String(255), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    decided_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    decided_at = db.Column(db.DateTime)
    student = db.relationship("Student", backref="payments")
    session = db.relationship("Session")


class Registration(db.Model):
    __tablename__ = "registrations"
    __table_args__ = (db.UniqueConstraint("student_id", "semester_id"),)
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id"), nullable=False)
    semester_id = db.Column(db.Integer, db.ForeignKey("semesters.id"), nullable=False)
    status = db.Column(db.String(12), default="draft", nullable=False)
    submitted_at = db.Column(db.DateTime)
    approved_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    approved_at = db.Column(db.DateTime)
    remark = db.Column(db.String(255), default="")
    student = db.relationship("Student", backref="registrations")
    semester = db.relationship("Semester")
    approved_by_user = db.relationship("User", foreign_keys=[approved_by])
    courses = db.relationship("RegistrationCourse", backref="registration",
                              cascade="all, delete-orphan")

    @property
    def total_units(self):
        return sum(rc.course.units for rc in self.courses)


class RegistrationCourse(db.Model):
    __tablename__ = "registration_courses"
    __table_args__ = (db.UniqueConstraint("registration_id", "course_id"),)
    id = db.Column(db.Integer, primary_key=True)
    registration_id = db.Column(db.Integer, db.ForeignKey("registrations.id"), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey("courses.id"), nullable=False)
    course = db.relationship("Course")
    result = db.relationship("Result", backref="registration_course", uselist=False)


class Result(db.Model):
    __tablename__ = "results"
    __table_args__ = (
        db.CheckConstraint("ca_score >= 0 AND ca_score <= 100", name="ck_ca_range"),
        db.CheckConstraint("exam_score >= 0 AND exam_score <= 100", name="ck_exam_range"),
    )
    id = db.Column(db.Integer, primary_key=True)
    registration_course_id = db.Column(db.Integer,
        db.ForeignKey("registration_courses.id"), unique=True, nullable=False)
    ca_score = db.Column(db.Float, default=0, nullable=False)
    exam_score = db.Column(db.Float, default=0, nullable=False)
    total = db.Column(db.Float, default=0, nullable=False)
    grade = db.Column(db.String(2))
    points = db.Column(db.Integer, default=0, nullable=False)
    status = db.Column(db.String(12), default="draft", nullable=False)
    entered_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    approved_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def recompute(self):
        self.total = (self.ca_score or 0) + (self.exam_score or 0)
        g = GradeScale.grade_for(self.total)
        self.grade = g.letter if g else None
        self.points = g.points if g else 0


class Notification(db.Model):
    __tablename__ = "notifications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(120), nullable=False)
    body = db.Column(db.String(255), default="")
    link = db.Column(db.String(200), default="")
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("User", backref="notifications")


class AuditLog(db.Model):
    __tablename__ = "audit_logs"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    action = db.Column(db.String(50), nullable=False)
    entity = db.Column(db.String(50), nullable=False)
    entity_id = db.Column(db.Integer)
    detail = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("User")


def audit(user_id, action, entity, entity_id=None, detail=""):
    db.session.add(AuditLog(user_id=user_id, action=action, entity=entity,
                            entity_id=entity_id, detail=detail))


def notify(user_id, title, body="", link=""):
    db.session.add(Notification(user_id=user_id, title=title, body=body, link=link))


def next_matric(programme, entry_year):
    prefix = f"{programme.code}/{entry_year}/"
    count = Student.query.filter(Student.matric_no.like(prefix + "%")).count()
    return f"{prefix}{count + 1:03d}"


def invoice_no(student, session):
    return f"INV-{session.name.replace('/', '')}-{student.id:05d}"


def fee_amount(student, session):
    """Exact level fee → all-levels fee → global fallback."""
    row = FeeSchedule.query.filter_by(session_id=session.id,
                                      programme_id=student.programme_id,
                                      level=student.level).first()
    if not row:
        row = FeeSchedule.query.filter_by(session_id=session.id,
                                          programme_id=student.programme_id,
                                          level=0).first()
    if row:
        return float(row.amount)
    return float(Setting.get_int("school_fees_amount", 50000))


# ---------- GPA / CGPA engine ----------

def _approved_rows(student, semester=None):
    q = (db.session.query(Result, Course)
         .join(RegistrationCourse, Result.registration_course_id == RegistrationCourse.id)
         .join(Registration, RegistrationCourse.registration_id == Registration.id)
         .join(Course, RegistrationCourse.course_id == Course.id)
         .filter(Registration.student_id == student.id, Result.status == "approved"))
    if semester is not None:
        q = q.filter(Registration.semester_id == semester.id)
    return q.all()


def _weighted(rows, best_attempt=False):
    picked = {}
    for r, c in rows:
        if best_attempt and c.id in picked and picked[c.id][0].points >= r.points:
            continue
        picked[c.id] = (r, c)
    qp = sum(r.points * c.units for r, c in picked.values())
    units = sum(c.units for _, c in picked.values())
    return round(qp / units, 2) if units else 0.0


def student_gpa(student, semester):
    return _weighted(_approved_rows(student, semester))


def student_cgpa(student):
    return _weighted(_approved_rows(student), best_attempt=True)


def carryovers(student):
    best = {}
    for r, c in _approved_rows(student):
        if c.id not in best or r.points > best[c.id][0].points:
            best[c.id] = (r, c)
    out = []
    for r, c in best.values():
        gs = GradeScale.query.filter_by(letter=r.grade).first()
        if gs and not gs.is_pass:
            out.append(c)
    return sorted(out, key=lambda c: c.code)


def degree_class(cgpa):
    if cgpa >= 4.50:
        return "First Class Honours"
    if cgpa >= 3.50:
        return "Second Class Honours (Upper Division)"
    if cgpa >= 2.40:
        return "Second Class Honours (Lower Division)"
    if cgpa >= 1.50:
        return "Third Class Honours"
    if cgpa >= 1.00:
        return "Pass"
    return "Fail"