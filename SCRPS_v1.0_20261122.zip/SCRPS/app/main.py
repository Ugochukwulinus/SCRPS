from flask import Blueprint, render_template
from flask_login import login_required, current_user
from sqlalchemy import or_
from app.auth import is_adviser, adviser_assignments
from app.models import (Student, Lecturer, LevelAdviser, Course, CourseAllocation,
                        Semester, Session, Registration, RegistrationCourse,
                        Result, FeeClearance, Programme, Payment, User, student_cgpa)

bp = Blueprint("main", __name__)

REG_LABELS = {"draft": "In progress", "submitted": "Awaiting adviser approval",
              "approved": "Approved", "rejected": "Rejected — see your adviser"}


def _pending(assignments, limit=None):
    if not assignments:
        return []
    conds = [(Student.programme_id == a.programme_id) & (Student.level == a.level)
             for a in assignments]
    q = (Registration.query.join(Student, Registration.student_id == Student.id)
         .filter(or_(*conds), Registration.status == "submitted")
         .order_by(Registration.submitted_at.desc()))
    return q.limit(limit).all() if limit else q.all()


@bp.route("/")
@login_required
def dashboard():
    role = current_user.role
    cards, allocations, reg_info, pending_preview, notes = [], [], None, [], []
    open_sem = (Semester.query.filter_by(registration_open=True)
                .order_by(Semester.id.desc()).first())
    session = Session.query.filter_by(is_current=True).first()
    adv = is_adviser(current_user)

    if role == "student":
        s = current_user.student
        cleared = bool(session and FeeClearance.query.filter_by(
            student_id=s.id, session_id=session.id).first())
        cards = [("Programme", s.programme.name, ""),
                 ("Level", f"{s.level} Level", f"Matric: {s.matric_no}"),
                 ("CGPA", f"{student_cgpa(s):.2f}", "Best attempt per course"),
                 ("School Fees", "Cleared" if cleared else "Not paid",
                  session.name if session else "")]
        if not cleared:
            notes.append("Pay your school fees to unlock course registration.")
        if open_sem:
            reg = Registration.query.filter_by(student_id=s.id, semester_id=open_sem.id).first()
            reg_info = {"semester": open_sem.label,
                        "status": REG_LABELS.get(reg.status, reg.status) if reg else "Not started",
                        "units": reg.total_units if reg else 0}

    elif role in ("lecturer", "adviser", "hod"):
        lect = current_user.lecturer
        if open_sem:
            allocations = CourseAllocation.query.filter_by(
                lecturer_id=lect.id, semester_id=open_sem.id).all()
        cards = [("Department", lect.department.name, ""),
                 ("My Courses", len(allocations),
                  open_sem.label if open_sem else "No open semester")]
        if not allocations:
            notes.append("No courses are allocated to you yet. The administrator "
                         "assigns courses under Admin → Allocations.")
        if adv and role != "hod":
            assignments = adviser_assignments(current_user)
            all_pending = _pending(assignments)
            pending_preview = _pending(assignments, limit=8)
            levels = ", ".join(f"{a.level}L" for a in assignments) or "—"
            cards += [("Advising Levels", levels, "Programme " +
                       (assignments[0].programme.code if assignments else "")),
                      ("Pending Approvals", len(all_pending), "Submitted registrations")]
            if not assignments:
                notes.append("You have the Adviser role but no level is assigned yet. "
                             "Ask the administrator to assign you under Admin → Advisers.")
        elif role == "lecturer":
            notes.append("To approve student registrations you must be assigned as a "
                         "level adviser (Admin → Advisers).")
        if role == "hod":
            awaiting = (Result.query
                        .join(RegistrationCourse, Result.registration_course_id == RegistrationCourse.id)
                        .join(Course, RegistrationCourse.course_id == Course.id)
                        .filter(Course.department_id == lect.department_id,
                                Result.status == "submitted").count())
            cards += [("Results Awaiting Approval", awaiting, "Submitted by lecturers")]

    elif role == "bursary":
        pays = Payment.query.all()
        collected = sum(p.amount for p in pays if p.status == "confirmed")
        cards = [("Total Collected", f"₦{collected:,.0f}", ""),
                 ("Transactions", len(pays), ""),
                 ("Cleared Students", FeeClearance.query.count(), "All sessions"),
                 ("Students", Student.query.count(), "")]

    else:
        cards = [("Students", Student.query.count(), ""),
                 ("Staff", Lecturer.query.count() + User.query.filter_by(role="bursary").count(), ""),
                 ("Courses", Course.query.count(), ""),
                 ("Registration", "OPEN" if open_sem else "CLOSED",
                  open_sem.label if open_sem else "No semester open")]

    return render_template("dashboard.html", cards=cards, allocations=allocations,
                           reg_info=reg_info, open_sem=open_sem,
                           pending_preview=pending_preview, notes=notes)