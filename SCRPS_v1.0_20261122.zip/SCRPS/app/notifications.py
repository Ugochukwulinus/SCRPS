from flask import Blueprint, render_template
from flask_login import login_required, current_user
from app.models import db, Notification

bp = Blueprint("notifications", __name__, url_prefix="/notifications")


@bp.route("/")
@login_required
def inbox():
    items = (Notification.query.filter_by(user_id=current_user.id)
             .order_by(Notification.id.desc()).limit(100).all())
    for n in items:
        n.is_read = True
    db.session.commit()
    return render_template("notifications.html", items=items)