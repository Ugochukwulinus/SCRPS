from flask import render_template, request, redirect, url_for, abort, flash
from flask_login import current_user
from app.admin import bp
from app.admin.helpers import save, F, R, A
from app.models import db, audit, FeeSchedule, Session, Programme

LEVELS = [(0, "All levels")] + [(l, f"{l} Level") for l in (100, 200, 300, 400, 500)]


@bp.route("/fee-schedule")
def fee_schedule():
    rows = [R([f.session.name, f.programme.code,
               "All levels" if f.level == 0 else f"{f.level} Level",
               f"₦{f.amount:,.0f}"],
              [A("Edit", url_for(".fee_schedule_form", id=f.id)),
               A("Delete", url_for(".fee_schedule_delete", id=f.id),
                 post=True, cls="btn-danger")])
            for f in FeeSchedule.query.order_by(FeeSchedule.session_id.desc()).all()]
    return render_template("admin/table.html", title="Fee Schedule",
                           columns=["Session", "Programme", "Level", "Amount"], rows=rows,
                           add_url=url_for(".fee_schedule_form"), add_label="Set a fee")


@bp.route("/fee-schedule/add", methods=["GET", "POST"])
@bp.route("/fee-schedule/<int:id>/edit", methods=["GET", "POST"])
def fee_schedule_form(id=None):
    f = db.session.get(FeeSchedule, id) if id else FeeSchedule()
    if id and not f:
        abort(404)
    sessions = Session.query.order_by(Session.name.desc()).all()
    progs = Programme.query.order_by(Programme.code).all()
    if not sessions or not progs:
        flash("Create a session and a programme first.", "error")
        return redirect(url_for(".fee_schedule"))
    if request.method == "POST":
        amount = float(request.form["amount"])
        if amount <= 0:
            flash("Amount must be greater than zero.", "error")
        else:
            f.session_id = int(request.form["session_id"])
            f.programme_id = int(request.form["programme_id"])
            f.level = int(request.form["level"])
            f.amount = amount
            if not id:
                db.session.add(f)
            audit(current_user.id, "save", "fee_schedule", id, f"₦{amount:,.0f}")
            if save("Fee saved."):
                return redirect(url_for(".fee_schedule"))
    current = Session.query.filter_by(is_current=True).first()
    fields = [F("session_id", "Session", "select",
                f.session_id or (current.id if current else None),
                [(s.id, s.name) for s in sessions]),
              F("programme_id", "Programme", "select", f.programme_id,
                [(p.id, p.name) for p in progs]),
              F("level", "Level", "select", f.level or 0, LEVELS),
              F("amount", "Amount (₦)", "number", f.amount or 50000)]
    return render_template("admin/form.html", title="School Fee", fields=fields,
                           cancel_url=url_for(".fee_schedule"))


@bp.route("/fee-schedule/<int:id>/delete", methods=["POST"])
def fee_schedule_delete(id):
    f = db.session.get(FeeSchedule, id) or abort(404)
    db.session.delete(f)
    audit(current_user.id, "delete", "fee_schedule", id)
    save("Fee removed.")
    return redirect(url_for(".fee_schedule"))