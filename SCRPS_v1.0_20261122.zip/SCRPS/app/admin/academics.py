from datetime import date
from flask import render_template, request, redirect, url_for, abort, flash
from flask_login import current_user
from app.admin import bp
from app.admin.helpers import save, F, R, A
from app.models import (db, audit, Faculty, Department, Programme, Course,
                        Curriculum, CurriculumItem, Session, Semester, CourseAllocation)

LEVELS = [(l, f"{l} Level") for l in (100, 200, 300, 400, 500)]


@bp.route("/")
def index():
    return redirect(url_for(".departments"))


# ---------------- Faculties ----------------
@bp.route("/faculties")
def faculties():
    rows = [R([f.code, f.name, len(f.departments)],
              [A("Edit", url_for(".faculty_form", id=f.id)),
               A("Delete", url_for(".faculty_delete", id=f.id), post=True, cls="btn-danger")])
            for f in Faculty.query.order_by(Faculty.code).all()]
    return render_template("admin/table.html", title="Faculties",
                           columns=["Code", "Name", "Departments"], rows=rows,
                           add_url=url_for(".faculty_form"), add_label="New Faculty")


@bp.route("/faculties/add", methods=["GET", "POST"])
@bp.route("/faculties/<int:id>/edit", methods=["GET", "POST"])
def faculty_form(id=None):
    f = db.session.get(Faculty, id) if id else Faculty()
    if id and not f:
        abort(404)
    if request.method == "POST":
        f.code = request.form["code"].strip().upper()
        f.name = request.form["name"].strip()
        if not id:
            db.session.add(f)
        audit(current_user.id, "save", "faculty", id, f.code)
        if save("Faculty saved."):
            return redirect(url_for(".faculties"))
    fields = [F("code", "Code", value=f.code or ""), F("name", "Name", value=f.name or "")]
    return render_template("admin/form.html", title="Faculty", fields=fields,
                           cancel_url=url_for(".faculties"))


@bp.route("/faculties/<int:id>/delete", methods=["POST"])
def faculty_delete(id):
    f = db.session.get(Faculty, id) or abort(404)
    db.session.delete(f)
    audit(current_user.id, "delete", "faculty", id, f.code)
    save("Faculty deleted.")
    return redirect(url_for(".faculties"))


# ---------------- Departments ----------------
@bp.route("/departments")
def departments():
    rows = [R([d.code, d.name, d.faculty.code if d.faculty else "—",
               len(d.programmes), len(d.courses)],
              [A("Edit", url_for(".department_form", id=d.id)),
               A("Delete", url_for(".department_delete", id=d.id), post=True, cls="btn-danger")])
            for d in Department.query.order_by(Department.code).all()]
    return render_template("admin/table.html", title="Departments",
                           columns=["Code", "Name", "Faculty", "Programmes", "Courses"],
                           rows=rows, add_url=url_for(".department_form"),
                           add_label="New Department")


@bp.route("/departments/add", methods=["GET", "POST"])
@bp.route("/departments/<int:id>/edit", methods=["GET", "POST"])
def department_form(id=None):
    d = db.session.get(Department, id) if id else Department()
    if id and not d:
        abort(404)
    facs = Faculty.query.order_by(Faculty.code).all()
    if request.method == "POST":
        d.code = request.form["code"].strip().upper()
        d.name = request.form["name"].strip()
        d.faculty_id = int(request.form["faculty_id"])
        if not id:
            db.session.add(d)
        audit(current_user.id, "save", "department", id, d.code)
        if save("Department saved."):
            return redirect(url_for(".departments"))
    if not facs:
        flash("Create a faculty first — every department belongs to a faculty.", "error")
        return redirect(url_for(".faculty_form"))
    fields = [F("code", "Code", value=d.code or ""),
              F("name", "Name", value=d.name or ""),
              F("faculty_id", "Faculty", "select", d.faculty_id,
                [(f.id, f.name) for f in facs])]
    return render_template("admin/form.html", title="Department", fields=fields,
                           cancel_url=url_for(".departments"))

@bp.route("/departments/<int:id>/delete", methods=["POST"])
def department_delete(id):
    d = db.session.get(Department, id) or abort(404)
    db.session.delete(d)
    audit(current_user.id, "delete", "department", id, d.code)
    save("Department deleted.")
    return redirect(url_for(".departments"))


# ---------------- Programmes ----------------
@bp.route("/programmes")
def programmes():
    rows = [R([p.code, p.name, p.department.code, p.duration_years, len(p.students)],
              [A("Edit", url_for(".programme_form", id=p.id)),
               A("Delete", url_for(".programme_delete", id=p.id), post=True, cls="btn-danger")])
            for p in Programme.query.order_by(Programme.code).all()]
    return render_template("admin/table.html", title="Programmes",
                           columns=["Code", "Name", "Department", "Years", "Students"], rows=rows,
                           add_url=url_for(".programme_form"), add_label="New Programme")


@bp.route("/programmes/add", methods=["GET", "POST"])
@bp.route("/programmes/<int:id>/edit", methods=["GET", "POST"])
def programme_form(id=None):
    p = db.session.get(Programme, id) if id else Programme()
    if id and not p:
        abort(404)
    depts = Department.query.order_by(Department.code).all()
    if request.method == "POST":
        p.code = request.form["code"].strip().upper()
        p.name = request.form["name"].strip()
        p.department_id = int(request.form["department_id"])
        p.duration_years = int(request.form["duration_years"])
        if not id:
            db.session.add(p)
        audit(current_user.id, "save", "programme", id, p.code)
        if save("Programme saved."):
            return redirect(url_for(".programmes"))
    fields = [F("code", "Code", value=p.code or ""),
              F("name", "Name", value=p.name or ""),
              F("department_id", "Department", "select", p.department_id,
                [(d.id, d.name) for d in depts]),
              F("duration_years", "Duration (years)", "number", p.duration_years or 4)]
    return render_template("admin/form.html", title="Programme", fields=fields,
                           cancel_url=url_for(".programmes"))


@bp.route("/programmes/<int:id>/delete", methods=["POST"])
def programme_delete(id):
    p = db.session.get(Programme, id) or abort(404)
    db.session.delete(p)
    audit(current_user.id, "delete", "programme", id, p.code)
    save("Programme deleted.")
    return redirect(url_for(".programmes"))


# ---------------- Courses ----------------
@bp.route("/courses")
def courses():
    rows = [R([c.code, c.title, c.units, c.department.code,
               ", ".join(p.code for p in c.prereqs) or "—"],
              [A("Edit", url_for(".course_form", id=c.id)),
               A("Delete", url_for(".course_delete", id=c.id), post=True, cls="btn-danger")])
            for c in Course.query.order_by(Course.code).all()]
    return render_template("admin/table.html", title="Courses",
                           columns=["Code", "Title", "Units", "Dept", "Prerequisites"], rows=rows,
                           add_url=url_for(".course_form"), add_label="New Course")


@bp.route("/courses/add", methods=["GET", "POST"])
@bp.route("/courses/<int:id>/edit", methods=["GET", "POST"])
def course_form(id=None):
    c = db.session.get(Course, id) if id else Course()
    if id and not c:
        abort(404)
    depts = Department.query.order_by(Department.code).all()
    all_courses = Course.query.order_by(Course.code).all()
    if request.method == "POST":
        c.code = request.form["code"].strip().upper()
        c.title = request.form["title"].strip()
        c.units = int(request.form["units"])
        c.department_id = int(request.form["department_id"])
        if not 1 <= c.units <= 10:
            flash("Units must be between 1 and 10.", "error")
        else:
            selected = [db.session.get(Course, int(x))
                        for x in request.form.getlist("prereqs")]
            c.prereqs = [p for p in selected if p and p is not c]
            if not id:
                db.session.add(c)
            audit(current_user.id, "save", "course", id, c.code)
            if save("Course saved."):
                return redirect(url_for(".courses"))
    fields = [F("code", "Course code", value=c.code or ""),
              F("title", "Title", value=c.title or ""),
              F("units", "Credit units", "number", c.units or 3),
              F("department_id", "Department", "select", c.department_id,
                [(d.id, d.name) for d in depts]),
              F("prereqs", "Prerequisites (Ctrl+click for multiple)", "multiselect",
                [str(p.id) for p in c.prereqs],
                [(x.id, f"{x.code} — {x.title}") for x in all_courses], required=False)]
    return render_template("admin/form.html", title="Course", fields=fields,
                           cancel_url=url_for(".courses"))


@bp.route("/courses/<int:id>/delete", methods=["POST"])
def course_delete(id):
    c = db.session.get(Course, id) or abort(404)
    db.session.delete(c)
    audit(current_user.id, "delete", "course", id, c.code)
    save("Course deleted.")
    return redirect(url_for(".courses"))


# ---------------- Curricula (versioned) ----------------
@bp.route("/curricula")
def curricula():
    rows = [R([cur.programme.code, cur.entry_year, cur.label or "—", len(cur.items)],
              [A("Open", url_for(".curriculum_detail", id=cur.id)),
               A("Delete", url_for(".curriculum_delete", id=cur.id), post=True, cls="btn-danger")])
            for cur in Curriculum.query.order_by(Curriculum.entry_year.desc()).all()]
    return render_template("admin/table.html", title="Curricula (versioned by entry year)",
                           columns=["Programme", "Entry year", "Label", "Courses"], rows=rows,
                           add_url=url_for(".curriculum_add"), add_label="New Curriculum Version")


@bp.route("/curricula/add", methods=["GET", "POST"])
def curriculum_add():
    progs = Programme.query.order_by(Programme.code).all()
    existing = Curriculum.query.order_by(Curriculum.entry_year.desc()).all()
    if request.method == "POST":
        cur = Curriculum(programme_id=int(request.form["programme_id"]),
                         entry_year=int(request.form["entry_year"]),
                         label=request.form.get("label", "").strip())
        db.session.add(cur)
        src_id = request.form.get("copy_from")
        if src_id:
            src = db.session.get(Curriculum, int(src_id))
            for it in src.items:
                db.session.add(CurriculumItem(curriculum=cur, course_id=it.course_id,
                                              level=it.level, semester=it.semester,
                                              requirement=it.requirement))
        audit(current_user.id, "create", "curriculum", None)
        if save("Curriculum created."):
            return redirect(url_for(".curriculum_detail", id=cur.id))
    fields = [F("programme_id", "Programme", "select", None,
                [(p.id, p.name) for p in progs]),
              F("entry_year", "Entry year", "number", date.today().year),
              F("label", "Label (optional)", value="", required=False),
              F("copy_from", "Copy courses from (optional)", "select", "",
                [("", "— start empty —")] +
                [(c.id, f"{c.programme.code} {c.entry_year}") for c in existing],
                required=False)]
    return render_template("admin/form.html", title="New Curriculum Version", fields=fields,
                           cancel_url=url_for(".curricula"))


@bp.route("/curricula/<int:id>")
def curriculum_detail(id):
    cur = db.session.get(Curriculum, id) or abort(404)
    items = sorted(cur.items, key=lambda i: (i.level, i.semester, i.course.code))
    rows = [R([i.course.code, i.course.title, i.level, i.semester,
               i.course.units, i.requirement],
              [A("Remove", url_for(".curriculum_item_remove", item_id=i.id),
                 post=True, cls="btn-danger")]) for i in items]
    course_options = [(c.id, f"{c.code} — {c.title}")
                      for c in Course.query.order_by(Course.code).all()]
    total_units = sum(i.course.units for i in cur.items)
    return render_template("admin/curriculum.html", cur=cur, rows=rows,
                           course_options=course_options, levels=LEVELS,
                           total_units=total_units)


@bp.route("/curricula/<int:id>/items/add", methods=["POST"])
def curriculum_item_add(id):
    cur = db.session.get(Curriculum, id) or abort(404)
    course_id = int(request.form["course_id"])
    if CurriculumItem.query.filter_by(curriculum_id=id, course_id=course_id).first():
        flash("That course is already in this curriculum.", "error")
    else:
        db.session.add(CurriculumItem(curriculum=cur, course_id=course_id,
                                      level=int(request.form["level"]),
                                      semester=int(request.form["semester"]),
                                      requirement=request.form["requirement"]))
        audit(current_user.id, "add_item", "curriculum", id)
        save("Course added to curriculum.")
    return redirect(url_for(".curriculum_detail", id=id))


@bp.route("/curricula/items/<int:item_id>/remove", methods=["POST"])
def curriculum_item_remove(item_id):
    it = db.session.get(CurriculumItem, item_id) or abort(404)
    cur_id = it.curriculum_id
    db.session.delete(it)
    audit(current_user.id, "remove_item", "curriculum", cur_id)
    save("Course removed from curriculum.")
    return redirect(url_for(".curriculum_detail", id=cur_id))


@bp.route("/curricula/<int:id>/delete", methods=["POST"])
def curriculum_delete(id):
    cur = db.session.get(Curriculum, id) or abort(404)
    db.session.delete(cur)
    audit(current_user.id, "delete", "curriculum", id)
    save("Curriculum deleted.")
    return redirect(url_for(".curricula"))


# ---------------- Sessions & Semesters ----------------
@bp.route("/sessions")
def sessions():
    rows = []
    for s in Session.query.order_by(Session.name.desc()).all():
        sems = sorted(s.semesters, key=lambda x: x.number)
        cells = [s.name, "✔ Current" if s.is_current else ""] + \
                ["OPEN" if sm.registration_open else "Closed" for sm in sems]
        acts = []
        if not s.is_current:
            acts.append(A("Make current", url_for(".session_current", id=s.id), post=True))
        for sm in sems:
            acts.append(A(("Close" if sm.registration_open else "Open") + f" S{sm.number} reg.",
                          url_for(".semester_toggle", id=sm.id), post=True))
        acts.append(A("Roll over", url_for(".session_rollover", id=s.id), post=True,
                      confirm="Create the next session and copy all course allocations?"))
        rows.append(R(cells, acts))
    return render_template("admin/table.html", title="Sessions & Registration Windows",
                           columns=["Session", "Current", "Semester 1", "Semester 2"], rows=rows,
                           add_url=url_for(".session_add"), add_label="New Session")


@bp.route("/sessions/add", methods=["GET", "POST"])
def session_add():
    if request.method == "POST":
        s = Session(name=request.form["name"].strip())
        db.session.add(s)
        for n in (1, 2):
            db.session.add(Semester(session=s, number=n))
        audit(current_user.id, "create", "session", None, s.name)
        if save("Session created with both semesters."):
            return redirect(url_for(".sessions"))
    fields = [F("name", "Session name", value="", help="e.g. 2026/2027")]
    return render_template("admin/form.html", title="New Session", fields=fields,
                           cancel_url=url_for(".sessions"))


@bp.route("/sessions/<int:id>/current", methods=["POST"])
def session_current(id):
    s = db.session.get(Session, id) or abort(404)
    Session.query.update({"is_current": False})
    s.is_current = True
    audit(current_user.id, "set_current", "session", id, s.name)
    save(f"{s.name} is now the current session.")
    return redirect(url_for(".sessions"))


@bp.route("/semesters/<int:id>/toggle", methods=["POST"])
def semester_toggle(id):
    sm = db.session.get(Semester, id) or abort(404)
    opening = not sm.registration_open
    if opening:  # only one registration window open at a time
        Semester.query.update({"registration_open": False})
    sm.registration_open = opening
    audit(current_user.id, "toggle_registration", "semester", id,
          f"{sm.label} -> {'open' if opening else 'closed'}")
    save(f"Registration {'opened' if opening else 'closed'} for {sm.label}.")
    return redirect(url_for(".sessions"))

@bp.route("/sessions/<int:id>/rollover", methods=["POST"])
def session_rollover(id):
    """One click: create next session, make it current, copy course allocations."""
    s = db.session.get(Session, id) or abort(404)
    try:
        a, b = s.name.split("/")
        nxt = f"{int(a) + 1}/{int(b) + 1}"
    except ValueError:
        flash("Session name must look like 2026/2027 to roll over.", "error")
        return redirect(url_for(".sessions"))
    if Session.query.filter_by(name=nxt).first():
        flash(f"{nxt} already exists.", "error")
        return redirect(url_for(".sessions"))
    Session.query.update({"is_current": False})
    new = Session(name=nxt, is_current=True)
    db.session.add(new)
    db.session.flush()
    copied = 0
    for n in (1, 2):
        old_sem = Semester.query.filter_by(session_id=s.id, number=n).first()
        new_sem = Semester(session_id=new.id, number=n)
        db.session.add(new_sem)
        db.session.flush()
        if old_sem:
            for alloc in CourseAllocation.query.filter_by(semester_id=old_sem.id).all():
                db.session.add(CourseAllocation(lecturer_id=alloc.lecturer_id,
                                                course_id=alloc.course_id,
                                                semester_id=new_sem.id))
                copied += 1
    audit(current_user.id, "rollover", "session", new.id,
          f"{s.name} -> {nxt}; {copied} allocations copied")
    save(f"Rolled over to {nxt}. {copied} allocations copied. Open a registration window when ready.")
    return redirect(url_for(".sessions"))