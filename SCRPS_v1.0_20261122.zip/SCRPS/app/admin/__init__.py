from flask import Blueprint, redirect, url_for, abort
from flask_login import current_user

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.before_request
def guard():
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login"))
    if current_user.role != "admin":
        abort(403)


from app.admin import academics, people, system, feeschedule  # noqa: E402,F401