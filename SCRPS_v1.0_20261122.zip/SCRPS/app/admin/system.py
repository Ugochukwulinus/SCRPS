from flask import render_template, request, redirect, url_for, abort, flash
from flask_login import current_user
from app.admin import bp
from app.admin.helpers import save, F, R, A
from app.models import db, audit, Setting, GradeScale, AuditLog

INT_SETTINGS = [("ca_max", "Maximum CA score", "30"),
                ("exam_max", "Maximum exam score", "70"),
                ("min_units", "Minimum units per semester", "15"),
                ("max_units", "Maximum units per semester", "24"),
                ("pass_mark", "Pass mark", "40"),
                ("promotion_min_units", "Passed units required to advance a level", "24"),
                ("school_fees_amount", "School fees per session (₦)", "50000")]


@bp.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        try:
            values = {k: int(request.form[k]) for k, _, _ in INT_SETTINGS}
        except ValueError:
            flash("All settings must be whole numbers.", "error")
            return redirect(url_for(".settings"))
        if min(values.values()) < 0 or values["min_units"] > values["max_units"]:
            flash("Invalid values: nothing may be negative, and min units ≤ max units.", "error")
            return redirect(url_for(".settings"))
        for k, v in values.items():
            row = db.session.get(Setting, k) or Setting(key=k)
            row.value = str(v)
            db.session.add(row)
        signup = Setting(key="allow_student_signup",
                         value="1" if request.form.get("allow_student_signup") else "0")
        db.session.merge(signup)
        audit(current_user.id, "update", "settings")
        if save("Settings saved."):
            return redirect(url_for(".settings"))
    fields = [F(k, label, "number", Setting.get(k, default)) for k, label, default in INT_SETTINGS]
    fields.append(F("allow_student_signup", "Allow students to sign up themselves",
                    "checkbox", Setting.get("allow_student_signup", "1") == "1", required=False))
    return render_template("admin/form.html", title="System Settings", fields=fields,
                           cancel_url=url_for("main.dashboard"), submit="Save Settings")


@bp.route("/grades")
def grades():
    rows = [R([g.letter, g.min_score, g.max_score, g.points, "Pass" if g.is_pass else "Fail"],
              [A("Edit", url_for(".grade_form", id=g.id)),
               A("Delete", url_for(".grade_delete", id=g.id), post=True, cls="btn-danger")])
            for g in GradeScale.query.order_by(GradeScale.min_score.desc()).all()]
    return render_template("admin/table.html", title="Grading Scale",
                           columns=["Grade", "Min", "Max", "Points", "Outcome"], rows=rows,
                           add_url=url_for(".grade_form"), add_label="Add Grade Band")


@bp.route("/grades/add", methods=["GET", "POST"])
@bp.route("/grades/<int:id>/edit", methods=["GET", "POST"])
def grade_form(id=None):
    g = db.session.get(GradeScale, id) if id else GradeScale()
    if id and not g:
        abort(404)
    if request.method == "POST":
        letter = request.form["letter"].strip().upper()
        lo, hi = int(request.form["min_score"]), int(request.form["max_score"])
        pts = int(request.form["points"])
        if not (0 <= lo <= hi <= 100 and pts >= 0):
            flash("Scores must satisfy 0 ≤ min ≤ max ≤ 100, points ≥ 0.", "error")
        else:
            overlap = GradeScale.query.filter(GradeScale.min_score <= hi,
                                              GradeScale.max_score >= lo)
            if id:
                overlap = overlap.filter(GradeScale.id != id)
            if overlap.first():
                flash("This range overlaps an existing grade band — fix the ranges.", "error")
            else:
                g.letter, g.min_score, g.max_score, g.points = letter, lo, hi, pts
                g.is_pass = request.form.get("is_pass") == "1"
                if not id:
                    db.session.add(g)
                audit(current_user.id, "save", "grade", id, letter)
                if save("Grade band saved."):
                    return redirect(url_for(".grades"))
    fields = [F("letter", "Grade letter", value=g.letter or ""),
              F("min_score", "Minimum score", "number", g.min_score if id else 0),
              F("max_score", "Maximum score", "number", g.max_score if id else 100),
              F("points", "Grade points", "number", g.points if id else 0),
              F("is_pass", "Counts as a pass", "checkbox", g.is_pass if id else True, required=False)]
    return render_template("admin/form.html", title="Grade Band", fields=fields,
                           cancel_url=url_for(".grades"))


@bp.route("/grades/<int:id>/delete", methods=["POST"])
def grade_delete(id):
    g = db.session.get(GradeScale, id) or abort(404)
    db.session.delete(g)
    audit(current_user.id, "delete", "grade", id, g.letter)
    save("Grade band deleted.")
    return redirect(url_for(".grades"))


@bp.route("/audit")
def audit_log():
    logs = AuditLog.query.order_by(AuditLog.id.desc()).limit(200).all()
    rows = [R([l.created_at.strftime("%Y-%m-%d %H:%M") if l.created_at else "",
               l.user.full_name if l.user else "—", l.action, l.entity, l.detail or ""])
            for l in logs]
    return render_template("admin/table.html", title="Audit Log (latest 200 actions)",
                           columns=["When", "Who", "Action", "Entity", "Detail"], rows=rows)