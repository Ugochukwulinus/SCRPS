from flask import flash
from sqlalchemy.exc import IntegrityError
from app.models import db


def save(message):
    """Commit with integrity protection — FK violations become friendly errors."""
    try:
        db.session.commit()
        flash(message, "success")
        return True
    except IntegrityError:
        db.session.rollback()
        flash("Cannot save: duplicate value, or this record is referenced "
              "by other records (delete those first).", "error")
        return False


def F(name, label, type="text", value="", options=None, required=True, help="", step=None):
    return dict(name=name, label=label, type=type, value=value,
                options=options or [], required=required, help=help, step=step)


def R(cells, actions=None):
    return dict(cells=cells, actions=actions or [])


def A(label, url, post=False, cls="btn-light", confirm="Are you sure?"):
    return dict(label=label, url=url, post=post, cls=cls, confirm=confirm)