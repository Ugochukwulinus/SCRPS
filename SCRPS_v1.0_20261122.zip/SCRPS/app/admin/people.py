from flask import render_template, request, redirect, url_for, abort, flash
from flask_login import current_user
from app.admin import bp
from app.admin.helpers import save, F, R, A
from app.models import (db, audit, User, Student, Lecturer, Department, Programme,
                        LevelAdviser, Course, CourseAllocation, Semester, Session,
                        FeeClearance, Registration, next_matric)

LEVELS = [(l, f"{l} Level") for l in (100, 200, 300, 400, 500)]
STAFF_ROLES = [("lecturer", "Lecturer"), ("hod", "HOD / Exams Officer"), ("adviser", "Course Adviser")]


def _dept_options():
    return [(d.id, d.name) for d in Department.query.order_by(Department.code).all()]


def _prog_options():
    return [(p.id, p.name) for p in Programme.query.order_by(Programme.code).all()]


# ---------------- Staff (Lecturers / HODs / Advisers) ----------------
@bp.route("/staff")
def staff():
    rows = [R([l.staff_no, l.user.full_name, l.user.role.upper(), l.department.code,
               "Active" if l.user.active else "Deactivated"],
              [A("Edit", url_for(".staff_form", id=l.id)),
               A("Deactivate" if l.user.active else "Activate",
                 url_for(".staff_toggle", id=l.id), post=True)])
            for l in Lecturer.query.order_by(Lecturer.staff_no).all()]
    return render_template("admin/table.html", title="Staff",
                           columns=["Staff ID", "Name", "Role", "Dept", "Status"], rows=rows,
                           add_url=url_for(".staff_form"), add_label="New Staff Member")


@bp.route("/staff/add", methods=["GET", "POST"])
@bp.route("/staff/<int:id>/edit", methods=["GET", "POST"])
def staff_form(id=None):
    l = db.session.get(Lecturer, id) if id else None
    if id and not l:
        abort(404)
    if request.method == "POST":
        staff_no = request.form["staff_no"].strip().upper()
        role = request.form["role"]
        pw = request.form.get("password", "")
        if role not in dict(STAFF_ROLES):
            flash("Invalid role.", "error")
        elif not id and len(pw) < 6:
            flash("Password must be at least 6 characters.", "error")
        else:
            if l:
                l.user.full_name = request.form["full_name"].strip()
                l.user.role = role
                l.user.username = staff_no
                l.staff_no = staff_no
                l.department_id = int(request.form["department_id"])
                if pw:
                    l.user.set_password(pw)
            else:
                u = User(username=staff_no, full_name=request.form["full_name"].strip(), role=role)
                u.set_password(pw)
                l = Lecturer(user=u, staff_no=staff_no,
                             department_id=int(request.form["department_id"]))
                db.session.add_all([u, l])
            audit(current_user.id, "save", "staff", id, staff_no)
            if save("Staff member saved."):
                return redirect(url_for(".staff"))
    fields = [F("full_name", "Full name", value=l.user.full_name if l else ""),
              F("staff_no", "Staff ID (also the login username)", value=l.staff_no if l else ""),
              F("role", "Role", "select", l.user.role if l else "lecturer", STAFF_ROLES),
              F("department_id", "Department", "select", l.department_id if l else None, _dept_options()),
              F("password", "Password" if not l else "New password (blank = keep current)",
                "password", required=not l)]
    return render_template("admin/form.html", title="Staff Member", fields=fields,
                           cancel_url=url_for(".staff"))


@bp.route("/staff/<int:id>/toggle", methods=["POST"])
def staff_toggle(id):
    l = db.session.get(Lecturer, id) or abort(404)
    l.user.active = not l.user.active
    audit(current_user.id, "toggle_active", "staff", id, l.staff_no)
    save(f"{l.user.full_name} {'activated' if l.user.active else 'deactivated'}.")
    return redirect(url_for(".staff"))


# ---------------- Students ----------------
@bp.route("/students")
def students():
    rows = [R([s.matric_no, s.user.full_name, s.programme.code, s.level, s.entry_year,
               "Active" if s.user.active else "Deactivated"],
              [A("Edit", url_for(".student_form", id=s.id)),
               A("Deactivate" if s.user.active else "Activate",
                 url_for(".student_toggle", id=s.id), post=True)])
            for s in Student.query.order_by(Student.matric_no).all()]
    return render_template("admin/table.html", title="Students",
                           columns=["Matric No", "Name", "Programme", "Level", "Entry year", "Status"],
                           rows=rows, add_url=url_for(".student_form"), add_label="New Student")


@bp.route("/students/add", methods=["GET", "POST"])
@bp.route("/students/<int:id>/edit", methods=["GET", "POST"])
def student_form(id=None):
    s = db.session.get(Student, id) if id else None
    if id and not s:
        abort(404)
    if request.method == "POST":
        matric = request.form.get("matric_no", "").strip().upper()
        if not matric:
            prog = db.session.get(Programme, int(request.form["programme_id"]))
            matric = next_matric(prog, int(request.form["entry_year"]))
        pw = request.form.get("password", "")
        if not id and len(pw) < 6:
            flash("Password must be at least 6 characters.", "error")
        else:
            if s:
                s.user.full_name = request.form["full_name"].strip()
                s.user.username = matric
                s.matric_no = matric
                s.programme_id = int(request.form["programme_id"])
                s.entry_year = int(request.form["entry_year"])
                s.level = int(request.form["level"])
                if pw:
                    s.user.set_password(pw)
            else:
                u = User(username=matric, full_name=request.form["full_name"].strip(), role="student")
                u.set_password(pw)
                s = Student(user=u, matric_no=matric,
                            programme_id=int(request.form["programme_id"]),
                            entry_year=int(request.form["entry_year"]),
                            level=int(request.form["level"]))
                db.session.add_all([u, s])
            audit(current_user.id, "save", "student", id, matric)
            if save("Student saved."):
                return redirect(url_for(".students"))
    fields = [F("full_name", "Full name", value=s.user.full_name if s else ""),
              F("matric_no", "Matric number (also the login username)", value=s.matric_no if s else ""),
              F("programme_id", "Programme", "select", s.programme_id if s else None, _prog_options()),
              F("entry_year", "Entry year (binds curriculum version)", "number",
                s.entry_year if s else 2026),
              F("level", "Level", "select", s.level if s else 100, LEVELS),
              F("password", "Password" if not s else "New password (blank = keep current)",
                "password", required=not s)]
    return render_template("admin/form.html", title="Student", fields=fields,
                           cancel_url=url_for(".students"))


@bp.route("/students/<int:id>/toggle", methods=["POST"])
def student_toggle(id):
    s = db.session.get(Student, id) or abort(404)
    s.user.active = not s.user.active
    audit(current_user.id, "toggle_active", "student", id, s.matric_no)
    save(f"{s.user.full_name} {'activated' if s.user.active else 'deactivated'}.")
    return redirect(url_for(".students"))


# ---------------- Level Advisers ----------------
@bp.route("/advisers")
def advisers():
    rows = [R([la.programme.code, la.level, la.lecturer.user.full_name],
              [A("Remove", url_for(".adviser_remove", id=la.id), post=True, cls="btn-danger")])
            for la in LevelAdviser.query.all()]
    return render_template("admin/table.html", title="Level Adviser Assignments",
                           columns=["Programme", "Level", "Adviser"], rows=rows,
                           add_url=url_for(".adviser_add"), add_label="Assign Adviser")


@bp.route("/advisers/add", methods=["GET", "POST"])
def adviser_add():
    if request.method == "POST":
        db.session.add(LevelAdviser(lecturer_id=int(request.form["lecturer_id"]),
                                    programme_id=int(request.form["programme_id"]),
                                    level=int(request.form["level"])))
        audit(current_user.id, "assign", "adviser")
        if save("Adviser assigned."):
            return redirect(url_for(".advisers"))
    lects = Lecturer.query.order_by(Lecturer.staff_no).all()
    fields = [F("lecturer_id", "Staff member", "select", None,
                [(l.id, f"{l.staff_no} — {l.user.full_name}") for l in lects]),
              F("programme_id", "Programme", "select", None, _prog_options()),
              F("level", "Level", "select", 100, LEVELS)]
    return render_template("admin/form.html", title="Assign Level Adviser", fields=fields,
                           cancel_url=url_for(".advisers"))


@bp.route("/advisers/<int:id>/remove", methods=["POST"])
def adviser_remove(id):
    la = db.session.get(LevelAdviser, id) or abort(404)
    db.session.delete(la)
    audit(current_user.id, "remove", "adviser", id)
    save("Assignment removed.")
    return redirect(url_for(".advisers"))


# ---------------- Course Allocations ----------------
@bp.route("/allocations")
def allocations():
    rows = [R([a.semester.label, a.course.code, a.course.title, a.lecturer.user.full_name],
              [A("Remove", url_for(".allocation_remove", id=a.id), post=True, cls="btn-danger")])
            for a in CourseAllocation.query.join(Semester).order_by(Semester.id.desc()).all()]
    return render_template("admin/table.html", title="Course Allocations (who teaches what)",
                           columns=["Semester", "Course", "Title", "Lecturer"], rows=rows,
                           add_url=url_for(".allocation_add"), add_label="Allocate Course")


@bp.route("/allocations/add", methods=["GET", "POST"])
def allocation_add():
    if request.method == "POST":
        db.session.add(CourseAllocation(lecturer_id=int(request.form["lecturer_id"]),
                                        course_id=int(request.form["course_id"]),
                                        semester_id=int(request.form["semester_id"])))
        audit(current_user.id, "allocate", "course")
        if save("Course allocated. Only this lecturer can enter its scores."):
            return redirect(url_for(".allocations"))
    lects = Lecturer.query.order_by(Lecturer.staff_no).all()
    crs = Course.query.order_by(Course.code).all()
    sems = Semester.query.join(Session).order_by(Session.name.desc(), Semester.number).all()
    open_sem = Semester.query.filter_by(registration_open=True).first()
    fields = [F("semester_id", "Semester", "select", open_sem.id if open_sem else None,
                [(s.id, s.label) for s in sems]),
              F("course_id", "Course", "select", None,
                [(c.id, f"{c.code} — {c.title}") for c in crs]),
              F("lecturer_id", "Lecturer", "select", None,
                [(l.id, f"{l.staff_no} — {l.user.full_name}") for l in lects])]
    return render_template("admin/form.html", title="Allocate Course", fields=fields,
                           cancel_url=url_for(".allocations"))


@bp.route("/allocations/<int:id>/remove", methods=["POST"])
def allocation_remove(id):
    a = db.session.get(CourseAllocation, id) or abort(404)
    db.session.delete(a)
    audit(current_user.id, "remove", "allocation", id)
    save("Allocation removed.")
    return redirect(url_for(".allocations"))


# ---------------- Fee Clearance ----------------
@bp.route("/fees")
def fees():
    sess = Session.query.filter_by(is_current=True).first()
    if not sess:
        flash("Create a session and mark it current first.", "error")
        return redirect(url_for(".sessions"))
    cleared = {f.student_id for f in FeeClearance.query.filter_by(session_id=sess.id).all()}
    rows = []
    for s in Student.query.order_by(Student.matric_no).all():
        ok = s.id in cleared
        rows.append(R([s.matric_no, s.user.full_name, s.level,
                       "Cleared" if ok else "Not cleared"],
                      [A("Revoke" if ok else "Mark cleared",
                         url_for(".fee_toggle", id=s.id), post=True)]))
    return render_template("admin/table.html", title=f"Fee Clearance — {sess.name}",
                           columns=["Matric No", "Name", "Level", "Status"], rows=rows)


@bp.route("/fees/<int:id>/toggle", methods=["POST"])
def fee_toggle(id):
    s = db.session.get(Student, id) or abort(404)
    sess = Session.query.filter_by(is_current=True).first() or abort(404)
    f = FeeClearance.query.filter_by(student_id=s.id, session_id=sess.id).first()
    if f:
        db.session.delete(f)
    else:
        db.session.add(FeeClearance(student_id=s.id, session_id=sess.id,
                                    cleared_by=current_user.id))
    audit(current_user.id, "toggle_fees", "student", id, s.matric_no)
    save("Fee status updated.")
    return redirect(url_for(".fees"))

@bp.route("/registrations")
def registrations_report():
    regs = Registration.query.order_by(Registration.id.desc()).limit(300).all()
    rows = [R([r.student.matric_no, r.student.user.full_name, r.semester.label,
               r.total_units, r.status,
               r.submitted_at.strftime("%Y-%m-%d %H:%M") if r.submitted_at else "—"])
            for r in regs]
    return render_template("admin/table.html", title="All Registrations (latest 300)",
                           columns=["Matric", "Student", "Semester", "Units",
                                    "Status", "Submitted"], rows=rows)

@bp.route("/officers")
def officers():
    rows = [R([u.username, u.full_name, "Bursary", "Active" if u.active else "Deactivated"],
              [A("Deactivate" if u.active else "Activate",
                 url_for(".officer_toggle", id=u.id), post=True)])
            for u in User.query.filter_by(role="bursary").all()]
    return render_template("admin/table.html", title="Bursary Officers",
                           columns=["Username", "Name", "Role", "Status"], rows=rows,
                           add_url=url_for(".officer_add"), add_label="New Bursary Officer")


@bp.route("/officers/add", methods=["GET", "POST"])
def officer_add():
    if request.method == "POST":
        username = request.form["username"].strip()
        pw = request.form.get("password", "")
        if len(pw) < 6:
            flash("Password must be at least 6 characters.", "error")
        else:
            u = User(username=username, full_name=request.form["full_name"].strip(),
                     role="bursary")
            u.set_password(pw)
            db.session.add(u)
            audit(current_user.id, "create", "officer", None, username)
            if save("Bursary officer created."):
                return redirect(url_for(".officers"))
    fields = [F("full_name", "Full name"), F("username", "Username"),
              F("password", "Password", "password")]
    return render_template("admin/form.html", title="Bursary Officer", fields=fields,
                           cancel_url=url_for(".officers"))


@bp.route("/officers/<int:id>/toggle", methods=["POST"])
def officer_toggle(id):
    u = db.session.get(User, id) or abort(404)
    u.active = not u.active
    audit(current_user.id, "toggle_active", "officer", id, u.username)
    save("Officer status updated.")
    return redirect(url_for(".officers"))