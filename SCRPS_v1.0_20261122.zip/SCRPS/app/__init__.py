import sqlite3
from flask import Flask, render_template
from flask_login import LoginManager, current_user
from flask_wtf.csrf import CSRFProtect
from sqlalchemy import event, inspect, text
from sqlalchemy.engine import Engine
from config import Config
from app.models import db, User, Notification
from app.menu import build_menu

login_manager = LoginManager()
csrf = CSRFProtect()

ROLE_LABELS = {"admin": "Administrator", "student": "Student",
               "lecturer": "Lecturer", "adviser": "Course Adviser",
               "hod": "HOD / Exams Officer", "bursary": "Bursary Officer"}


@event.listens_for(Engine, "connect")
def _sqlite_pragmas(dbapi_connection, connection_record):
    if isinstance(dbapi_connection, sqlite3.Connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=5000")
        cursor.close()


def ensure_columns():
    insp = inspect(db.engine)
    for table in db.metadata.sorted_tables:
        if not insp.has_table(table.name):
            continue
        existing = {c["name"] for c in insp.get_columns(table.name)}
        for col in table.columns:
            if col.name in existing:
                continue
            coltype = col.type.compile(db.engine.dialect)
            db.session.execute(text(
                f'ALTER TABLE "{table.name}" ADD COLUMN "{col.name}" {coltype}'))
    db.session.commit()


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to continue."
    login_manager.login_message_category = "error"

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    from app.auth import bp as auth_bp, is_adviser
    from app.main import bp as main_bp
    from app.admin import bp as admin_bp
    from app.registration import bp as registration_bp
    from app.results import bp as results_bp
    from app.payments import bp as payments_bp
    from app.notifications import bp as notifications_bp
    for b in (auth_bp, main_bp, admin_bp, registration_bp, results_bp,
              payments_bp, notifications_bp):
        app.register_blueprint(b)

    @app.context_processor
    def inject_globals():
        if not current_user.is_authenticated:
            return dict(nav_items=[], unread_count=0, is_adviser=False,
                        role_label="", role_badge="")
        adv = is_adviser(current_user)
        role = current_user.role
        label = ("Course Adviser" if adv and role == "lecturer"
                 else ROLE_LABELS.get(role, role.title()))
        badge = "adviser" if adv and role == "lecturer" else role
        unread = Notification.query.filter_by(user_id=current_user.id,
                                              is_read=False).count()
        return dict(nav_items=build_menu(current_user), unread_count=unread,
                    is_adviser=adv, role_label=label, role_badge=badge)

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("error.html", code=403,
                               message="You do not have permission to access that page."), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404,
                               message="The page you requested does not exist."), 404

    with app.app_context():
        db.create_all()
        ensure_columns()

    return app