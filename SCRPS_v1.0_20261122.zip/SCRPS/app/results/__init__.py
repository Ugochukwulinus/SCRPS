from flask import Blueprint

bp = Blueprint("results", __name__, url_prefix="/results")

from app.results import lecturer, hod, student  # noqa: E402,F401