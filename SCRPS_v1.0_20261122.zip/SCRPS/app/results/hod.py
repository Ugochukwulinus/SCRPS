from flask import render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.auth import role_required
from app.models import (db, audit, notify, Course, CourseAllocation, Student, Programme,
                        Registration, RegistrationCourse, Result, Semester, Session,
                        Setting, GradeScale, student_cgpa, carryovers)
from app.results import bp
from app.results.lecturer import _rows
from app.results.pdf import broadsheet_pdf


def _dept_filter(query):
    """HOD sees only their department; admin sees everything."""
    if current_user.role == "hod":
        query = query.filter(Course.department_id == current_user.lecturer.department_id)
    return query


def _dept_allocs():
    q = _dept_filter(CourseAllocation.query.join(Course))
    return q.order_by(CourseAllocation.semester_id.desc()).all()


@bp.route("/hod")
@login_required
@role_required("hod", "admin")
def hod_list():
    items = []
    for a in _dept_allocs():
        rows = _rows(a)
        if not rows:
            continue
        st = [rc.result.status if rc.result else "missing" for rc in rows]
        items.append({"alloc": a, "students": len(rows),
                      "missing": st.count("missing"), "draft": st.count("draft"),
                      "submitted": st.count("submitted"), "approved": st.count("approved")})
    return render_template("results/hod_list.html", items=items)


@bp.route("/review/<int:alloc_id>")
@login_required
@role_required("hod", "admin")
def review(alloc_id):
    a = db.session.get(CourseAllocation, alloc_id) or abort(404)
    return render_template("results/review.html", a=a, rows=_rows(a))


@bp.route("/review/<int:alloc_id>/approve", methods=["POST"])
@login_required
@role_required("hod", "admin")
def approve(alloc_id):
    a = db.session.get(CourseAllocation, alloc_id) or abort(404)
    rows = _rows(a)

    missing = [rc.registration.student.matric_no for rc in rows if not rc.result]
    if missing:
        flash("Cannot approve — scores missing for: " + ", ".join(missing), "error")
        return redirect(url_for(".review", alloc_id=a.id))

    drafts = [rc.registration.student.matric_no for rc in rows
              if rc.result and rc.result.status == "draft"]
    if drafts:
        flash("Cannot approve — unsubmitted draft scores for: " + ", ".join(drafts), "error")
        return redirect(url_for(".review", alloc_id=a.id))

    if not any(rc.result and rc.result.status == "submitted" for rc in rows):
        flash("Nothing to approve — no submitted results for this course.", "error")
        return redirect(url_for(".review", alloc_id=a.id))

    n = 0
    for rc in rows:
        if rc.result.status == "submitted":
            rc.result.status = "approved"
            rc.result.approved_by = current_user.id
            n += 1
    audit(current_user.id, "approve_results", "allocation", a.id,
          f"{a.course.code}: {n} results LOCKED")
    db.session.commit()
    for rc in rows:
        notify(rc.registration.student.user_id, "Result published",
               f"{a.course.code}: {rc.result.grade} ({rc.result.total:g})",
               url_for("results.my_results"))
    db.session.commit()
    flash(f"{n} result(s) approved and locked. Students notified.", "success")
    return redirect(url_for(".hod_list"))


@bp.route("/review/<int:alloc_id>/reject", methods=["POST"])
@login_required
@role_required("hod", "admin")
def reject(alloc_id):
    a = db.session.get(CourseAllocation, alloc_id) or abort(404)
    reason = request.form.get("reason", "").strip()
    if not reason:
        flash("A reason is required when returning results.", "error")
        return redirect(url_for(".review", alloc_id=a.id))
    for rc in _rows(a):
        if rc.result and rc.result.status == "submitted":
            rc.result.status = "draft"
    audit(current_user.id, "reject_results", "allocation", a.id,
          f"{a.course.code}: {reason}")
    db.session.commit()
    flash("Results returned to the lecturer for correction.", "success")
    return redirect(url_for(".hod_list"))


@bp.route("/review/<int:alloc_id>/broadsheet")
@login_required
@role_required("hod", "admin")
def broadsheet(alloc_id):
    a = db.session.get(CourseAllocation, alloc_id) or abort(404)
    return broadsheet_pdf(a, _rows(a))


# ---------- Automation: session processing & level promotion ----------

def _is_pass(result):
    gs = GradeScale.query.filter_by(letter=result.grade).first()
    return bool(gs and gs.is_pass)


def _session_rows(st, session):
    return (db.session.query(Result, Course)
            .join(RegistrationCourse, Result.registration_course_id == RegistrationCourse.id)
            .join(Registration, RegistrationCourse.registration_id == Registration.id)
            .join(Semester, Registration.semester_id == Semester.id)
            .join(Course, RegistrationCourse.course_id == Course.id)
            .filter(Registration.student_id == st.id,
                    Semester.session_id == session.id,
                    Result.status == "approved").all())


def _weighted(rows):
    qp = sum(r.points * c.units for r, c in rows)
    units = sum(c.units for _, c in rows)
    return round(qp / units, 2) if units else 0.0


def _pending_count(session):
    q = (Result.query
         .join(RegistrationCourse, Result.registration_course_id == RegistrationCourse.id)
         .join(Registration, RegistrationCourse.registration_id == Registration.id)
         .join(Semester, Registration.semester_id == Semester.id)
         .join(Course, RegistrationCourse.course_id == Course.id)
         .filter(Semester.session_id == session.id, Result.status != "approved"))
    return _dept_filter(q).count()


def _processing_rows(session):
    min_units = Setting.get_int("promotion_min_units", 24)
    q = (Registration.query
         .join(Semester, Registration.semester_id == Semester.id)
         .join(Student, Registration.student_id == Student.id)
         .join(Programme, Student.programme_id == Programme.id)
         .filter(Semester.session_id == session.id, Registration.status == "approved"))
    if current_user.role == "hod":
        q = q.filter(Programme.department_id == current_user.lecturer.department_id)
    out, seen = [], set()
    for reg in q.all():
        st = reg.student
        if st.id in seen:
            continue
        seen.add(st.id)
        rows = _session_rows(st, session)
        taken = sum(c.units for _, c in rows)
        passed = sum(c.units for r, c in rows if _is_pass(r))
        final_level = st.programme.duration_years * 100
        if passed >= min_units:
            decision = ("Graduation eligible" if st.level >= final_level
                        else f"Promote to {st.level + 100}L")
        else:
            decision = "Repeat level"
        out.append({"st": st, "taken": taken, "passed": passed,
                    "gpa": _weighted(rows), "cgpa": student_cgpa(st),
                    "carry": len(carryovers(st)), "decision": decision})
    out.sort(key=lambda x: x["st"].matric_no)
    return out


@bp.route("/processing")
@login_required
@role_required("hod", "admin")
def processing():
    sessions = Session.query.order_by(Session.name.desc()).all()
    sel = request.args.get("session", type=int)
    session = (db.session.get(Session, sel) if sel
               else Session.query.filter_by(is_current=True).first())
    if not session and sessions:
        session = sessions[0]
    rows = _processing_rows(session) if session else []
    pending = _pending_count(session) if session else 0
    return render_template("results/processing.html", sessions=sessions, session=session,
                           rows=rows, pending=pending,
                           min_units=Setting.get_int("promotion_min_units", 24))


@bp.route("/processing/apply", methods=["POST"])
@login_required
@role_required("hod", "admin")
def processing_apply():
    session = db.session.get(Session, int(request.form["session_id"])) or abort(404)
    if _pending_count(session):
        flash("Cannot process: some results are still draft or submitted. "
              "Approve or return them first.", "error")
        return redirect(url_for(".processing", session=session.id))
    rows = _processing_rows(session)
    if not rows:
        flash("No approved student records in this session.", "error")
        return redirect(url_for(".processing", session=session.id))
    promoted = repeated = graduated = 0
    for row in rows:
        st, decision = row["st"], row["decision"]
        if decision.startswith("Promote"):
            st.level += 100
            promoted += 1
            notify(st.user_id, "Level promotion",
                   f"You have been promoted to {st.level} Level.",
                   url_for("main.dashboard"))
        elif decision == "Repeat level":
            repeated += 1
            notify(st.user_id, "Academic standing",
                   f"You must repeat {st.level} Level. Carryovers: {row['carry']}.",
                   url_for("results.my_results"))
        else:
            graduated += 1
            notify(st.user_id, "Graduation eligibility",
                   "You have met the requirements for graduation. Contact Exams & Records.",
                   url_for("results.my_results"))
        audit(current_user.id, "session_processing", "student", st.id,
              f"{session.name}: {decision}")
    db.session.commit()
    flash(f"Session processed — {promoted} promoted, {repeated} to repeat, "
          f"{graduated} graduation-eligible. Students notified.", "success")
    return redirect(url_for(".processing", session=session.id))