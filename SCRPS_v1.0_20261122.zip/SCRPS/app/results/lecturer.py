import csv
import io
from flask import (render_template, request, redirect, url_for, flash, abort,
                   Response)
from flask_login import login_required, current_user
from app.auth import role_required
from app.models import (db, audit, Setting, Student, CourseAllocation, Registration,
                        RegistrationCourse, Result, AuditLog)
from app.results import bp


def _rows(alloc):
    """Registered (approved) students for this course + semester."""
    return (db.session.query(RegistrationCourse)
            .join(Registration, RegistrationCourse.registration_id == Registration.id)
            .join(Student, Registration.student_id == Student.id)
            .filter(Registration.semester_id == alloc.semester_id,
                    RegistrationCourse.course_id == alloc.course_id,
                    Registration.status == "approved")
            .order_by(Student.matric_no).all())


def _own_alloc(alloc_id):
    a = db.session.get(CourseAllocation, alloc_id) or abort(404)
    if a.lecturer_id != current_user.lecturer.id:
        abort(403)
    return a


@bp.route("/")
@login_required
@role_required("lecturer", "adviser")
def my_courses():
    items = []
    for a in (CourseAllocation.query.filter_by(lecturer_id=current_user.lecturer.id)
              .order_by(CourseAllocation.semester_id.desc()).all()):
        rows = _rows(a)
        st = [rc.result.status if rc.result else "missing" for rc in rows]
        items.append({"alloc": a, "students": len(rows),
                      "missing": st.count("missing"), "draft": st.count("draft"),
                      "submitted": st.count("submitted"), "approved": st.count("approved")})
    return render_template("results/lecturer_list.html", items=items)


@bp.route("/entry/<int:alloc_id>")
@login_required
@role_required("lecturer", "adviser")
def entry(alloc_id):
    a = _own_alloc(alloc_id)
    rows = _rows(a)
    editable = any(rc.result is None or rc.result.status == "draft" for rc in rows)
    reason = (AuditLog.query.filter_by(entity="allocation", entity_id=a.id,
                                       action="reject_results")
              .order_by(AuditLog.id.desc()).first())
    return render_template("results/entry.html", a=a, rows=rows, editable=editable,
                           ca_max=Setting.get_int("ca_max", 30),
                           exam_max=Setting.get_int("exam_max", 70),
                           reason=reason if editable else None)


@bp.route("/entry/<int:alloc_id>/save", methods=["POST"])
@login_required
@role_required("lecturer", "adviser")
def save_scores(alloc_id):
    a = _own_alloc(alloc_id)
    ca_max = Setting.get_int("ca_max", 30)
    exam_max = Setting.get_int("exam_max", 70)
    errors, parsed = [], []
    for rc in _rows(a):
        ca_raw = request.form.get(f"ca_{rc.id}", "").strip()
        ex_raw = request.form.get(f"exam_{rc.id}", "").strip()
        if not ca_raw and not ex_raw:
            continue
        matric = rc.registration.student.matric_no
        try:
            ca, ex = float(ca_raw), float(ex_raw)
        except ValueError:
            errors.append(f"{matric}: scores must be numbers.")
            continue
        if not 0 <= ca <= ca_max:
            errors.append(f"{matric}: CA must be between 0 and {ca_max}.")
        if not 0 <= ex <= exam_max:
            errors.append(f"{matric}: exam must be between 0 and {exam_max}.")
        parsed.append((rc, ca, ex))
    if errors:
        for e in errors:
            flash(e, "error")
        return redirect(url_for(".entry", alloc_id=a.id))
    saved = 0
    for rc, ca, ex in parsed:
        r = rc.result
        if r and r.status != "draft":
            continue
        if not r:
            r = Result(registration_course_id=rc.id)
            db.session.add(r)
        r.ca_score, r.exam_score = ca, ex
        r.entered_by = current_user.id
        r.recompute()
        saved += 1
    audit(current_user.id, "save_scores", "allocation", a.id,
          f"{a.course.code}: {saved} scores")
    db.session.commit()
    flash(f"{saved} score(s) saved as draft.", "success")
    return redirect(url_for(".entry", alloc_id=a.id))


@bp.route("/entry/<int:alloc_id>/submit", methods=["POST"])
@login_required
@role_required("lecturer", "adviser")
def submit_scores(alloc_id):
    a = _own_alloc(alloc_id)
    rows = _rows(a)
    missing = [rc.registration.student.matric_no for rc in rows if not rc.result]
    if missing:
        flash("Cannot submit — scores missing for: " + ", ".join(missing), "error")
        return redirect(url_for(".entry", alloc_id=a.id))
    n = 0
    for rc in rows:
        if rc.result.status == "draft":
            rc.result.status = "submitted"
            n += 1
    audit(current_user.id, "submit_results", "allocation", a.id,
          f"{a.course.code}: {n} results")
    db.session.commit()
    flash("Results submitted to the HOD for approval.", "success")
    return redirect(url_for(".my_courses"))


# ---------- Automation: CSV bulk score import ----------

@bp.route("/entry/<int:alloc_id>/template")
@login_required
@role_required("lecturer", "adviser")
def csv_template(alloc_id):
    """Pre-filled CSV: the lecturer only types CA and exam columns."""
    a = _own_alloc(alloc_id)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["matric", "student_name", "ca", "exam"])
    for rc in _rows(a):
        w.writerow([rc.registration.student.matric_no,
                    rc.registration.student.user.full_name, "", ""])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition":
                             f"attachment; filename=scores_{a.course.code}_{a.semester_id}.csv"})


@bp.route("/entry/<int:alloc_id>/import", methods=["GET", "POST"])
@login_required
@role_required("lecturer", "adviser")
def import_scores(alloc_id):
    """All-or-nothing import: any invalid row aborts the whole file."""
    a = _own_alloc(alloc_id)
    rows = _rows(a)
    ca_max = Setting.get_int("ca_max", 30)
    exam_max = Setting.get_int("exam_max", 70)

    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename:
            flash("Choose a CSV file first.", "error")
            return redirect(url_for(".import_scores", alloc_id=a.id))
        try:
            text = f.read().decode("utf-8-sig")
        except UnicodeDecodeError:
            flash("Save the file as CSV UTF-8 and try again.", "error")
            return redirect(url_for(".import_scores", alloc_id=a.id))

        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:
            flash("The file is empty.", "error")
            return redirect(url_for(".import_scores", alloc_id=a.id))
        cols = {c.strip().lower(): c for c in reader.fieldnames}
        if not {"matric", "ca", "exam"} <= set(cols):
            flash("CSV must contain columns: matric, ca, exam.", "error")
            return redirect(url_for(".import_scores", alloc_id=a.id))

        by_matric = {rc.registration.student.matric_no.upper(): rc for rc in rows}
        errors, parsed, seen = [], [], set()
        for i, row in enumerate(reader, start=2):
            matric = (row.get(cols["matric"]) or "").strip().upper()
            if not matric:
                continue
            if matric in seen:
                errors.append(f"Line {i}: duplicate matric {matric}.")
                continue
            seen.add(matric)
            rc = by_matric.get(matric)
            if not rc:
                errors.append(f"Line {i}: {matric} is not registered for this course.")
                continue
            if rc.result and rc.result.status != "draft":
                errors.append(f"Line {i}: {matric} is already {rc.result.status} (locked).")
                continue
            try:
                ca = float((row.get(cols["ca"]) or "").strip())
                ex = float((row.get(cols["exam"]) or "").strip())
            except ValueError:
                errors.append(f"Line {i}: {matric} — scores must be numbers.")
                continue
            if not 0 <= ca <= ca_max:
                errors.append(f"Line {i}: {matric} — CA must be 0–{ca_max}.")
            if not 0 <= ex <= exam_max:
                errors.append(f"Line {i}: {matric} — exam must be 0–{exam_max}.")
            parsed.append((rc, ca, ex))

        if errors:
            for e in errors[:20]:
                flash(e, "error")
            flash("Nothing was saved. Fix the file and import again.", "error")
            return redirect(url_for(".import_scores", alloc_id=a.id))
        if not parsed:
            flash("No score rows were found in the file.", "error")
            return redirect(url_for(".import_scores", alloc_id=a.id))

        for rc, ca, ex in parsed:
            r = rc.result
            if not r:
                r = Result(registration_course_id=rc.id)
                db.session.add(r)
            r.ca_score, r.exam_score = ca, ex
            r.entered_by = current_user.id
            r.recompute()
        audit(current_user.id, "import_scores", "allocation", a.id,
              f"{a.course.code}: {len(parsed)} rows imported")
        db.session.commit()
        flash(f"Imported {len(parsed)} score(s) as draft. Review, then submit to HOD.", "success")
        return redirect(url_for(".entry", alloc_id=a.id))

    return render_template("results/import.html", a=a, count=len(rows),
                           ca_max=ca_max, exam_max=exam_max)