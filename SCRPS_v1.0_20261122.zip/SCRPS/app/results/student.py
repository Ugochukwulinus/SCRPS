from flask import render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.auth import role_required
from app.models import (db, Course, Semester, Registration, RegistrationCourse,
                        Result, student_gpa, student_cgpa, carryovers, degree_class)
from app.results import bp
from app.results.pdf import slip_pdf, transcript_pdf


def _approved_rows(st, sem=None):
    q = (db.session.query(Result, Course)
         .join(RegistrationCourse, Result.registration_course_id == RegistrationCourse.id)
         .join(Registration, RegistrationCourse.registration_id == Registration.id)
         .join(Course, RegistrationCourse.course_id == Course.id)
         .filter(Registration.student_id == st.id, Result.status == "approved"))
    if sem:
        q = q.filter(Registration.semester_id == sem.id)
    return q.order_by(Course.code).all()


@bp.route("/my")
@login_required
@role_required("student")
def my_results():
    st = current_user.student
    sems = (Semester.query
            .join(Registration, Registration.semester_id == Semester.id)
            .join(RegistrationCourse, RegistrationCourse.registration_id == Registration.id)
            .join(Result, Result.registration_course_id == RegistrationCourse.id)
            .filter(Registration.student_id == st.id, Result.status == "approved")
            .distinct().order_by(Semester.id.desc()).all())
    sel = request.args.get("sem", type=int)
    sem = next((s for s in sems if s.id == sel), None) or (sems[0] if sems else None)
    cgpa = student_cgpa(st)
    return render_template("results/student.html", sems=sems, sem=sem,
                           rows=_approved_rows(st, sem) if sem else [],
                           gpa=student_gpa(st, sem) if sem else 0.0,
                           cgpa=cgpa, carryovers=carryovers(st),
                           degree=degree_class(cgpa))


@bp.route("/my/slip/<int:sem_id>")
@login_required
@role_required("student")
def slip(sem_id):
    st = current_user.student
    sem = db.session.get(Semester, sem_id) or abort(404)
    rows = _approved_rows(st, sem)
    if not rows:
        flash("No approved results for that semester yet.", "error")
        return redirect(url_for(".my_results"))
    return slip_pdf(st, sem, rows, student_gpa(st, sem), student_cgpa(st))


@bp.route("/my/transcript")
@login_required
@role_required("student")
def transcript():
    st = current_user.student
    rows = _approved_rows(st)
    if not rows:
        flash("No approved results yet — a transcript is not available.", "error")
        return redirect(url_for(".my_results"))
    groups = {}
    for r, c in rows:
        sem = r.registration_course.registration.semester
        groups.setdefault(sem, []).append((r, c))
    ordered = sorted(groups.items(), key=lambda kv: kv[0].id)
    return transcript_pdf(st, ordered, student_cgpa(st),
                          degree_class(student_cgpa(st)), student_gpa)