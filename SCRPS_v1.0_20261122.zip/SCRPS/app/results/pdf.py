from io import BytesIO
from flask import send_file
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle)

BLUE = colors.HexColor("#2563eb")
LINE = colors.HexColor("#dbe4f0")


def _base(title):
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18*mm, rightMargin=18*mm,
                            topMargin=18*mm, bottomMargin=18*mm)
    styles = getSampleStyleSheet()
    elems = [Paragraph("STUDENT COURSE REGISTRATION &amp; RESULT PROCESSING SYSTEM",
                       ParagraphStyle("t", parent=styles["Heading1"], fontSize=14,
                                      alignment=1, spaceAfter=2)),
             Paragraph(title, ParagraphStyle("s", parent=styles["Normal"],
                                             fontSize=11, alignment=1, spaceAfter=8))]
    return buf, doc, styles, elems


def _grid(data, widths, header=True):
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    style = [("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
             ("FONTSIZE", (0, 0), (-1, -1), 9),
             ("GRID", (0, 0), (-1, -1), 0.4, LINE),
             ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
             ("TOPPADDING", (0, 0), (-1, -1), 3),
             ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), BLUE),
                  ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                  ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]
    t.setStyle(TableStyle(style))
    return t


def _student_info(st, extra=None):
    data = [["Name:", st.user.full_name, "Matric No:", st.matric_no],
            ["Programme:", st.programme.name, "Level:", f"{st.level}"]]
    if extra:
        data.append(extra)
    t = Table(data, colWidths=[25*mm, 70*mm, 25*mm, 54*mm])
    t.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
                           ("FONTSIZE", (0, 0), (-1, -1), 9),
                           ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                           ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return t


def _finish(buf, doc, elems, filename):
    doc.build(elems)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name=filename,
                     mimetype="application/pdf")


def slip_pdf(st, sem, rows, gpa, cgpa):
    buf, doc, styles, elems = _base(f"Semester Result Slip — {sem.label}")
    elems += [_student_info(st), Spacer(1, 5*mm)]
    data = [["Code", "Course Title", "Units", "CA", "Exam", "Total", "Grade", "Points"]]
    for r, c in rows:
        data.append([c.code, c.title, str(c.units), f"{r.ca_score:g}",
                     f"{r.exam_score:g}", f"{r.total:g}", r.grade or "—", str(r.points)])
    elems.append(_grid(data, [18*mm, 68*mm, 13*mm, 13*mm, 14*mm, 15*mm, 15*mm, 18*mm]))
    elems.append(Spacer(1, 4*mm))
    elems.append(Paragraph(f"<b>Semester GPA:</b> {gpa:.2f} &nbsp;&nbsp; "
                           f"<b>CGPA:</b> {cgpa:.2f}", styles["Normal"]))
    elems.append(Spacer(1, 10*mm))
    elems.append(_grid([["_"*28, "_"*28], ["HOD / Exams Officer", "Date"]],
                       [87*mm, 87*mm], header=False))
    return _finish(buf, doc, elems,
                   f"ResultSlip_{st.matric_no}_{sem.id}.pdf")


def transcript_pdf(st, ordered, cgpa, degree, gpa_fn):
    buf, doc, styles, elems = _base("Academic Transcript")
    elems += [_student_info(st, ["Entry Year:", str(st.entry_year),
                                 "Programme Duration:",
                                 f"{st.programme.duration_years} years"]),
              Spacer(1, 5*mm)]
    for sem, rows in ordered:
        elems.append(Paragraph(f"<b>{sem.label}</b>", styles["Normal"]))
        data = [["Code", "Course Title", "Units", "Total", "Grade", "Points"]]
        for r, c in rows:
            data.append([c.code, c.title, str(c.units), f"{r.total:g}",
                         r.grade or "—", str(r.points)])
        data.append(["", "Semester GPA", "", "", "", f"{gpa_fn(st, sem):.2f}"])
        elems.append(_grid(data, [18*mm, 82*mm, 14*mm, 16*mm, 16*mm, 28*mm]))
        elems.append(Spacer(1, 4*mm))
    elems.append(Paragraph(f"<b>CUMULATIVE GPA (CGPA): {cgpa:.2f}</b> &nbsp;&nbsp; "
                           f"<b>Classification:</b> {degree}", styles["Normal"]))
    elems.append(Spacer(1, 10*mm))
    elems.append(_grid([["_"*28, "_"*28], ["Registrar", "Date"]],
                       [87*mm, 87*mm], header=False))
    return _finish(buf, doc, elems, f"Transcript_{st.matric_no}.pdf")


def broadsheet_pdf(a, rows):
    buf, doc, styles, elems = _base(f"Broadsheet — {a.course.code} {a.course.title}")
    elems += [Paragraph(f"{a.semester.label} · Lecturer: {a.lecturer.user.full_name}",
                        styles["Normal"]), Spacer(1, 4*mm)]
    data = [["Matric No", "Student Name", "CA", "Exam", "Total", "Grade", "Points"]]
    for rc in rows:
        r = rc.result
        data.append([rc.registration.student.matric_no,
                     rc.registration.student.user.full_name,
                     f"{r.ca_score:g}" if r else "—",
                     f"{r.exam_score:g}" if r else "—",
                     f"{r.total:g}" if r else "—",
                     (r.grade if r else "—") or "—",
                     str(r.points) if r else "—"])
    elems.append(_grid(data, [30*mm, 60*mm, 15*mm, 16*mm, 16*mm, 16*mm, 21*mm]))
    graded = [rc.result for rc in rows if rc.result and rc.result.grade]
    if graded:
        passed = sum(1 for r in graded if r.points > 0)
        elems.append(Spacer(1, 4*mm))
        elems.append(Paragraph(
            f"Entries: {len(graded)} · Passed: {passed} · "
            f"Failed: {len(graded) - passed} · "
            f"Pass rate: {100 * passed // len(graded)}%", styles["Normal"]))
    return _finish(buf, doc, elems, f"Broadsheet_{a.course.code}_{a.semester.id}.pdf")