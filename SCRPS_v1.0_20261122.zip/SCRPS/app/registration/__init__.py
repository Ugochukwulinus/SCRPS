from flask import Blueprint

bp = Blueprint("registration", __name__)

from app.registration import student, adviser  # noqa: E402,F401