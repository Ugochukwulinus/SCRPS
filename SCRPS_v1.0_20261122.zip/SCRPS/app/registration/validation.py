"""Central rule engine for course selection. Every validation the UDUS
portal violated (duplicates, mixed levels, hidden prerequisite failures,
fees, unit caps) is enforced here — both server-side and in the UI."""
from app.models import (db, Setting, GradeScale, Semester, Session,
                        FeeClearance, Registration, RegistrationCourse, Result)


def student_status(student):
    """What is the student allowed to do right now?"""
    sess = Session.query.filter_by(is_current=True).first()
    open_sem = Semester.query.filter_by(registration_open=True).first()
    fees_ok = False
    if sess:
        fees_ok = bool(FeeClearance.query.filter_by(
            student_id=student.id, session_id=sess.id).first())

    reg = None
    if open_sem:
        reg = Registration.query.filter_by(student_id=student.id,
                                           semester_id=open_sem.id).first()

    return {"semester": open_sem, "fees_ok": fees_ok, "registration": reg}


def _passed(course, student_id):
    """Best attempt on this course — is it a passing grade?
    Returns True (passed), False (failed), None (never attempted)."""
    rows = (db.session.query(Result)
            .join(RegistrationCourse,
                  Result.registration_course_id == RegistrationCourse.id)
            .join(Registration, RegistrationCourse.registration_id == Registration.id)
            .filter(Registration.student_id == student_id,
                    RegistrationCourse.course_id == course.id,
                    Result.status == "approved").all())
    if not rows:
        return None
    best = max(rows, key=lambda r: r.points)
    gs = GradeScale.query.filter_by(letter=best.grade).first()
    return gs.is_pass if gs else False


def validate_add(student, course, semester, registration):
    """Returns (ok, list_of_issues). Each issue is (severity, message).
    Severity: 'block' = cannot add, 'warn' = allowed but flagged."""
    issues = []

    # 1. Registration window
    if not semester or not semester.registration_open:
        return False, [("block", "Registration is not currently open.")]

    # 2. Fees
    fees_ok = bool(FeeClearance.query.filter_by(
        student_id=student.id, session_id=semester.session.id).first())
    if not fees_ok:
        issues.append(("block", f"School fees not cleared for {semester.session.name}. "
                       "Contact the administrator."))

    # 3. Already submitted / approved — cannot edit
    if registration and registration.status in ("submitted", "approved"):
        return False, [("block",
            f"Registration is {registration.status}; you cannot edit it. "
            "Contact your adviser to reject it back to draft.")]

    # 4. Duplicate
    if registration and any(rc.course_id == course.id for rc in registration.courses):
        issues.append(("block", f"{course.code} is already in your selection."))

     # 4b. Already passed — a passed course cannot be registered again
    if _passed(course, student.id) is True:
        issues.append(("block", f"{course.code} has already been passed — "
                       "you cannot register it again."))

    # 5. Curriculum membership — the CCMAS fix
    cur = student.curriculum()
    if not cur:
        return False, [("block", "No curriculum is configured for your entry year.")]
    item = next((i for i in cur.items if i.course_id == course.id), None)
    if item and item.semester != semester.number:
        issues.append(("block", f"{course.code} belongs to Semester {item.semester}; "
            f"this registration window is Semester {semester.number}."))
    if item is None:
        issues.append(("block",
            f"{course.code} is not in your entry-year ({student.entry_year}) curriculum."))
    elif item.level > student.level:
        # Retaking a FAILED course from a higher level is allowed (carryover);
        # a course you never took at a higher level is not.
        previous = _passed(course, student.id)
        if previous is False:
            issues.append(("warn", f"Retaking failed course {course.code}."))
        else:
            issues.append(("block",
                f"{course.code} is a {item.level} Level course — you are {student.level} Level."))

    # 6. Prerequisites
    failed_prereqs = []
    for p in course.prereqs:
        status = _passed(p, student.id)
        if status is False:
            failed_prereqs.append(p.code)
        elif status is None:
            # Co-registration allowed: prereq already in the current selection
            prereq_in_current = (registration and any(
                rc.course_id == p.id for rc in registration.courses))
            if not prereq_in_current:
                failed_prereqs.append(p.code)
    if failed_prereqs:
        issues.append(("block",
            f"Unmet prerequisite(s): {', '.join(failed_prereqs)}."))

    # 7. Unit cap (warn on min, block on max)
    current_units = registration.total_units if registration else 0
    new_total = current_units + course.units
    max_units = Setting.get_int("max_units", 24)
    min_units = Setting.get_int("min_units", 15)
    if new_total > max_units:
        issues.append(("block",
            f"Would exceed {max_units} units (you currently have {current_units})."))
    elif new_total < min_units:
        issues.append(("warn",
            f"You would have only {new_total} units (minimum is {min_units})."))

    return all(s != "block" for s, _ in issues), issues


def validate_submission(student, registration):
    """Pre-submission check. Returns list of blocking issues."""
    if not registration or not registration.courses:
        return ["Your selection is empty."]
    min_units = Setting.get_int("min_units", 15)
    max_units = Setting.get_int("max_units", 24)
    total = registration.total_units
    issues = []
    if total < min_units:
        issues.append(f"Total units ({total}) is below minimum ({min_units}).")
    if total > max_units:
        issues.append(f"Total units ({total}) exceeds maximum ({max_units}).")
    # Re-run per-course validation in case state changed since selection
    for rc in registration.courses:
        ok, course_issues = validate_add(student, rc.course,
                                          registration.semester, registration)
        if not ok:
            issues.append(f"{rc.course.code}: " +
                          "; ".join(m for s, m in course_issues if s == "block"))
    return issues