from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from sqlalchemy import or_
from app.auth import adviser_required, adviser_assignments
from app.models import db, audit, notify, Student, Registration, LevelAdviser
from app.registration import bp
from app.registration.pdf import course_form_pdf


def _scoped(reg):
    """Admin/HOD may review anything; an adviser only their own levels."""
    if current_user.role in ("hod", "admin"):
        return True
    return any(a.programme_id == reg.student.programme_id and a.level == reg.student.level
               for a in adviser_assignments(current_user))


def _my_pending(limit=None):
    assignments = adviser_assignments(current_user)
    if not assignments:
        return []
    conds = [(Student.programme_id == a.programme_id) & (Student.level == a.level)
             for a in assignments]
    q = (Registration.query.join(Student, Registration.student_id == Student.id)
         .filter(or_(*conds), Registration.status == "submitted")
         .order_by(Registration.submitted_at.desc()))
    if limit:
        q = q.limit(limit)
    return q.all()


@bp.route("/approve")
@login_required
@adviser_required
def approve_list():
    if current_user.role in ("hod", "admin"):
        regs = (Registration.query.filter_by(status="submitted")
                .order_by(Registration.submitted_at.desc()).all())
    else:
        regs = _my_pending()
    return render_template("approve_list.html",
                           rows=[(r, r.student) for r in regs])


@bp.route("/approve/<int:reg_id>")
@login_required
@adviser_required
def approve_detail(reg_id):
    reg = db.session.get(Registration, reg_id) or abort(404)
    if not _scoped(reg):
        abort(403)
    return render_template("approve_detail.html", reg=reg)


@bp.route("/approve/<int:reg_id>/approve", methods=["POST"])
@login_required
@adviser_required
def approve_approve(reg_id):
    reg = db.session.get(Registration, reg_id) or abort(404)
    if not _scoped(reg):
        abort(403)
    if reg.status != "submitted":
        flash("This registration is no longer awaiting approval.", "error")
        return redirect(url_for("registration.approve_list"))
    reg.status = "approved"
    reg.approved_by = current_user.id
    reg.approved_at = datetime.utcnow()
    reg.remark = request.form.get("remark", "").strip()
    audit(current_user.id, "approve", "registration", reg.id,
          f"{reg.student.matric_no} / {reg.total_units} units")
    notify(reg.student.user_id, "Registration approved",
           "Your course form is ready to download.", url_for("registration.register"))
    db.session.commit()
    flash(f"Approved for {reg.student.user.full_name}.", "success")
    return redirect(url_for("registration.approve_list"))


@bp.route("/approve/<int:reg_id>/reject", methods=["POST"])
@login_required
@adviser_required
def approve_reject(reg_id):
    reg = db.session.get(Registration, reg_id) or abort(404)
    if not _scoped(reg):
        abort(403)
    if reg.status != "submitted":
        flash("This registration is no longer awaiting approval.", "error")
        return redirect(url_for("registration.approve_list"))
    remark = request.form.get("remark", "").strip()
    if not remark:
        flash("You must give a reason when rejecting a registration.", "error")
        return redirect(url_for("registration.approve_detail", reg_id=reg.id))
    reg.status = "rejected"
    reg.approved_by = current_user.id
    reg.approved_at = datetime.utcnow()
    reg.remark = remark
    audit(current_user.id, "reject", "registration", reg.id,
          f"{reg.student.matric_no}: {remark}")
    notify(reg.student.user_id, "Registration rejected", remark,
           url_for("registration.register"))
    db.session.commit()
    flash("Registration rejected. The student can revise and resubmit.", "success")
    return redirect(url_for("registration.approve_list"))


@bp.route("/approve/<int:reg_id>/print")
@login_required
@adviser_required
def approve_print(reg_id):
    reg = db.session.get(Registration, reg_id) or abort(404)
    if not _scoped(reg):
        abort(403)
    return course_form_pdf(reg)