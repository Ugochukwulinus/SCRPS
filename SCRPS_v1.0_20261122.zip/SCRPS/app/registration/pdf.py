from io import BytesIO
from flask import send_file
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                Table, TableStyle)
from app.models import Setting


def course_form_pdf(reg):
    """Official printable course registration form — pure Python, no internet."""
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=20*mm, rightMargin=20*mm,
                            topMargin=20*mm, bottomMargin=20*mm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("Title", parent=styles["Heading1"],
                                 fontSize=16, spaceAfter=4, alignment=1)
    sub_style = ParagraphStyle("Sub", parent=styles["Normal"],
                               fontSize=11, alignment=1, spaceAfter=2)
    head_style = ParagraphStyle("Head", parent=styles["Heading2"],
                                fontSize=12, spaceAfter=6, spaceBefore=8)
    small_style = ParagraphStyle("Small", parent=styles["Normal"],
                                 fontSize=9, textColor=colors.grey)

    st = reg.student
    sem = reg.semester

    elements = []
    elements.append(Paragraph(
        "STUDENT COURSE REGISTRATION &amp; RESULT PROCESSING SYSTEM", title_style))
    elements.append(Paragraph("Official Course Registration Form", sub_style))
    elements.append(Spacer(1, 10*mm))

    info_data = [
        ["Student Name:", st.user.full_name, "Matric No:", st.matric_no],
        ["Programme:", f"{st.programme.code} - {st.programme.name}",
         "Level:", f"{st.level} Level"],
        ["Session:", sem.session.name, "Semester:", str(sem.number)],
        ["Curriculum:", f"{st.entry_year} entry", "Units registered:",
         str(reg.total_units)],
    ]
    info_table = Table(info_data, colWidths=[35*mm, 55*mm, 30*mm, 50*mm])
    info_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(info_table)
    elements.append(Spacer(1, 6*mm))

    elements.append(Paragraph("Registered Courses", head_style))
    course_data = [["#", "Code", "Title", "Units"]]
    for i, rc in enumerate(sorted(reg.courses,
                                   key=lambda r: r.course.code), start=1):
        course_data.append([str(i), rc.course.code, rc.course.title,
                            str(rc.course.units)])
    course_data.append(["", "", Paragraph("<b>Total</b>", styles["Normal"]),
                        Paragraph(f"<b>{reg.total_units}</b>", styles["Normal"])])

    course_table = Table(course_data, colWidths=[10*mm, 25*mm, 110*mm, 25*mm])
    course_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2563eb")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -2), 0.5, colors.HexColor("#dbe4f0")),
        ("LINEABOVE", (0, -1), (-1, -1), 1, colors.HexColor("#22334d")),
        ("ALIGN", (0, 0), (0, -1), "CENTER"),
        ("ALIGN", (-1, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(course_table)
    elements.append(Spacer(1, 8*mm))

    meta = []
    if reg.status == "approved":
        approver = reg.approved_by_user.full_name if reg.approved_by_user else "—"
        meta.append(f"Approved by: {approver}")
        if reg.approved_at:
            meta.append(f"on {reg.approved_at.strftime('%Y-%m-%d %H:%M')}")
    meta.append(f"Unit policy: {Setting.get_int('min_units', 15)}-"
                f"{Setting.get_int('max_units', 24)} units per semester")
    elements.append(Paragraph(" · ".join(meta), small_style))

    elements.append(Spacer(1, 12*mm))
    sig_data = [
        ["_" * 30, "_" * 30, "_" * 30],
        ["Student signature", "Adviser signature", "Date"],
    ]
    sig_table = Table(sig_data, colWidths=[55*mm, 55*mm, 55*mm])
    sig_table.setStyle(TableStyle([
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("FONTSIZE", (0, 1), (-1, 1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
    ]))
    elements.append(sig_table)

    doc.build(elements)
    buf.seek(0)
    filename = (f"CourseForm_{st.matric_no}_"
                f"{sem.session.name.replace('/', '_')}_S{sem.number}.pdf")
    return send_file(buf, as_attachment=True, download_name=filename,
                     mimetype="application/pdf")