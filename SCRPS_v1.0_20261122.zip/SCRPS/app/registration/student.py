from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.models import (db, audit, Course, Registration, RegistrationCourse,
                        LevelAdviser, Setting, notify)
from app.registration import bp
from app.registration.validation import (student_status, validate_add,
                                         validate_submission)
from app.registration.pdf import course_form_pdf


@bp.route("/register")
@login_required
def register():
    if current_user.role != "student":
        return redirect(url_for("main.dashboard"))
    st = current_user.student
    status = student_status(st)
    sem = status["semester"]
    reg = status["registration"]
    cur = st.curriculum()

    available = []
    if cur:
        already = {rc.course_id for rc in reg.courses} if reg else set()
        for item in cur.items:
            ok, issues = validate_add(st, item.course, sem, reg)
            severity = "block" if any(s == "block" for s, _ in issues) else "ok"
            reasons = "; ".join(m for s, m in issues if s == "block")
            available.append({
                "item": item,
                "ok": ok and item.course_id not in already,
                "severity": severity,
                "reasons": reasons,
                "added": item.course_id in already,
            })
        available.sort(key=lambda x: (x["item"].level, x["item"].semester,
                                      x["item"].course.code))

    return render_template("register.html", status=status, reg=reg,
                           available=available, cur=cur)


@bp.route("/register/add/<int:course_id>", methods=["POST"])
@login_required
def add(course_id):
    if current_user.role != "student":
        abort(403)
    st = current_user.student
    status = student_status(st)
    sem = status["semester"]
    course = db.session.get(Course, course_id) or abort(404)
    reg = status["registration"]

    ok, issues = validate_add(st, course, sem, reg)
    if not ok:
        flash(f"Cannot add {course.code}: " +
              "; ".join(m for s, m in issues if s == "block"), "error")
        return redirect(url_for("registration.register"))

    if not reg:
        reg = Registration(student_id=st.id, semester_id=sem.id, status="draft")
        db.session.add(reg)
        db.session.flush()
    db.session.add(RegistrationCourse(registration_id=reg.id, course_id=course.id))
    audit(current_user.id, "add_course", "registration", reg.id, course.code)
    db.session.commit()
    flash(f"Added {course.code}.", "success")
    return redirect(url_for("registration.register"))


@bp.route("/register/remove/<int:course_id>", methods=["POST"])
@login_required
def remove(course_id):
    if current_user.role != "student":
        abort(403)
    reg = student_status(current_user.student)["registration"]
    if not reg:
        abort(404)
    rc = RegistrationCourse.query.filter_by(registration_id=reg.id,
                                             course_id=course_id).first()
    if rc:
        code = rc.course.code
        db.session.delete(rc)
        audit(current_user.id, "remove_course", "registration", reg.id, code)
        db.session.commit()
        flash(f"Removed {code}.", "success")
    return redirect(url_for("registration.register"))


@bp.route("/register/submit", methods=["POST"])
@login_required
def submit():
    if current_user.role != "student":
        abort(403)
    st = current_user.student
    reg = student_status(st)["registration"]
    if not reg:
        flash("Nothing to submit.", "error")
        return redirect(url_for("registration.register"))

    issues = validate_submission(st, reg)
    if issues:
        for i in issues:
            flash(i, "error")
        return redirect(url_for("registration.register"))

    adviser = LevelAdviser.query.filter_by(programme_id=st.programme_id,
                                            level=st.level).first()
    if not adviser:
        flash("No course adviser is assigned to your level. Contact the administrator.", "error")
        return redirect(url_for("registration.register"))

    reg.status = "submitted"
    reg.submitted_at = datetime.utcnow()
    audit(current_user.id, "submit", "registration", reg.id,
          f"{reg.total_units} units")
    db.session.commit()
    notify(adviser.lecturer.user_id, "Registration awaiting your approval",
           f"{st.matric_no} — {reg.total_units} units",
           url_for("registration.approve_detail", reg_id=reg.id))
    db.session.commit()
    flash("Registration submitted to your adviser for approval.", "success")
    return redirect(url_for("registration.register"))


@bp.route("/register/print")
@login_required
def print_form():
    if current_user.role != "student":
        abort(403)
    reg = student_status(current_user.student)["registration"]
    if not reg or reg.status != "approved":
        flash("The course form is available only after your adviser approves it.", "error")
        return redirect(url_for("registration.register"))
    return course_form_pdf(reg)

@bp.route("/register/auto", methods=["POST"])
@login_required
def auto_register():
    """Automatically select every eligible course up to the unit cap."""
    if current_user.role != "student":
        abort(403)
    st = current_user.student
    status = student_status(st)
    sem, reg = status["semester"], status["registration"]
    if not sem:
        flash("Registration is not open.", "error")
        return redirect(url_for(".register"))
    if reg and reg.status in ("submitted", "approved"):
        flash("Your registration is already submitted or approved.", "error")
        return redirect(url_for(".register"))
    cur = st.curriculum()
    if not cur:
        flash("No curriculum configured for your entry year.", "error")
        return redirect(url_for(".register"))
    if not reg:
        reg = Registration(student_id=st.id, semester_id=sem.id, status="draft")
        db.session.add(reg); db.session.flush()
    max_units = Setting.get_int("max_units", 24)
    added, skipped = [], []
    items = sorted([i for i in cur.items
                    if i.semester == sem.number and i.level <= st.level],
                   key=lambda i: (i.level, i.course.code))
    for item in items:
        if reg.total_units + item.course.units > max_units:
            skipped.append(f"{item.course.code} (unit cap)")
            continue
        ok, issues = validate_add(st, item.course, sem, reg)
        if ok:
            db.session.add(RegistrationCourse(registration_id=reg.id,
                                              course_id=item.course.id))
            db.session.flush()
            added.append(item.course.code)
        else:
            skipped.append(f"{item.course.code} ({'; '.join(m for s, m in issues if s == 'block')})")
    audit(current_user.id, "auto_register", "registration", reg.id, ", ".join(added))
    db.session.commit()
    flash(f"Auto-registered {len(added)} course(s): {', '.join(added) or 'none'}.", "success")
    if skipped:
        flash("Skipped: " + "; ".join(skipped), "info")
    return redirect(url_for(".register"))