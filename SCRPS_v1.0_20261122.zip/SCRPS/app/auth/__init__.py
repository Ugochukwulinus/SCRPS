from datetime import date
from functools import wraps
from flask import (Blueprint, render_template, redirect, url_for, flash,
                   request, abort, session)
from flask_login import login_user, logout_user, current_user, login_required
from app.models import (db, User, Student, Programme, Setting, LevelAdviser,
                        audit, next_matric)
from app.admin.helpers import F

bp = Blueprint("auth", __name__)


def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if current_user.role not in roles:
                abort(403)
            return f(*args, **kwargs)
        return wrapper
    return decorator


def adviser_assignments(user):
    lect = getattr(user, "lecturer", None)
    if not lect:
        return []
    return LevelAdviser.query.filter_by(lecturer_id=lect.id).all()


def is_adviser(user):
    """Adviser capability = the Adviser role OR an actual level assignment."""
    if user.role == "adviser":
        return True
    return bool(adviser_assignments(user))


def adviser_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated:
            abort(403)
        if current_user.role in ("hod", "admin") or is_adviser(current_user):
            return f(*args, **kwargs)
        abort(403)
    return wrapper


@bp.route("/setup", methods=["GET", "POST"])
def setup():
    if User.query.count() > 0:
        abort(404)
    if request.method == "GET":
        session.pop("_flashes", None)
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        pw, confirm = request.form.get("password", ""), request.form.get("confirm", "")
        if not username or not full_name:
            flash("Username and full name are required.", "error")
        elif len(pw) < 6:
            flash("Password must be at least 6 characters.", "error")
        elif pw != confirm:
            flash("Passwords do not match.", "error")
        else:
            u = User(username=username, full_name=full_name, role="admin")
            u.set_password(pw)
            db.session.add(u)
            db.session.flush()
            audit(u.id, "setup", "user", u.id, "Administrator created")
            db.session.commit()
            flash("Administrator created. Please sign in.", "success")
            return redirect(url_for("auth.login"))
    fields = [F("full_name", "Administrator full name"),
              F("username", "Admin username"),
              F("password", "Password (min 6 characters)", "password"),
              F("confirm", "Confirm password", "password")]
    return render_template("admin/form.html",
                           title="First-time setup — create the administrator",
                           fields=fields, cancel_url=url_for("auth.login"),
                           submit="Create Administrator")


@bp.route("/signup", methods=["GET", "POST"])
def signup():
    if Setting.get("allow_student_signup", "1") != "1":
        flash("Student self-registration is disabled. Contact the administrator.", "error")
        return redirect(url_for("auth.login"))
    programmes = Programme.query.order_by(Programme.code).all()
    if not programmes:
        flash("No programmes are configured yet. Contact the administrator.", "error")
        return redirect(url_for("auth.login"))

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        pw, confirm = request.form.get("password", ""), request.form.get("confirm", "")
        errors = []
        if not full_name:
            errors.append("Full name is required.")
        if len(pw) < 6:
            errors.append("Password must be at least 6 characters.")
        if pw != confirm:
            errors.append("Passwords do not match.")
        try:
            programme_id = int(request.form["programme_id"])
            entry_year = int(request.form["entry_year"])
            level = int(request.form["level"])
            if not (1990 <= entry_year <= 2100) or level not in (100, 200, 300, 400, 500):
                errors.append("Invalid entry year or level.")
            if not db.session.get(Programme, programme_id):
                errors.append("Select a valid programme.")
        except (KeyError, ValueError):
            errors.append("Programme, entry year and level are required.")

        if errors:
            for e in errors:
                flash(e, "error")
        else:
            prog = db.session.get(Programme, programme_id)
            matric = next_matric(prog, entry_year)
            prefix, seq = matric.rsplit("/", 1)
            n = int(seq)
            while User.query.filter_by(username=matric).first():
                n += 1
                matric = f"{prefix}/{n:03d}"
            u = User(username=matric, full_name=full_name, role="student")
            u.set_password(pw)
            s = Student(user=u, matric_no=matric, programme_id=programme_id,
                        entry_year=entry_year, level=level)
            db.session.add_all([u, s])
            db.session.flush()
            audit(u.id, "signup", "student", s.id, matric)
            db.session.commit()
            login_user(u)
            flash(f"Account created. Your matriculation number is {matric} — "
                  f"use it to sign in next time.", "success")
            return redirect(url_for("main.dashboard"))

    return render_template("signup.html", programmes=programmes,
                           current_year=date.today().year)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if User.query.count() == 0:
        return redirect(url_for("auth.setup"))
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            if not user.active:
                flash("This account has been deactivated. Contact the administrator.", "error")
            else:
                login_user(user)
                audit(user.id, "login", "user", user.id, username)
                db.session.commit()
                session.pop("_flashes", None)
                return redirect(url_for("main.dashboard"))
        else:
            flash("Invalid username or password.", "error")
    return render_template("login.html")


@bp.route("/logout")
def logout():
    if current_user.is_authenticated:
        audit(current_user.id, "logout", "user", current_user.id)
        db.session.commit()
        logout_user()
    return redirect(url_for("auth.login"))


@bp.route("/password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        old = request.form.get("old", "")
        new = request.form.get("new", "")
        confirm = request.form.get("confirm", "")
        if not current_user.check_password(old):
            flash("Current password is incorrect.", "error")
        elif len(new) < 6:
            flash("New password must be at least 6 characters.", "error")
        elif new != confirm:
            flash("New passwords do not match.", "error")
        else:
            current_user.set_password(new)
            audit(current_user.id, "change_password", "user", current_user.id)
            db.session.commit()
            flash("Password changed.", "success")
            return redirect(url_for("main.dashboard"))
    return render_template("change_password.html")