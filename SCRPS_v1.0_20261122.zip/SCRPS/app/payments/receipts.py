from io import BytesIO
from flask import send_file
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle


def receipt_pdf(pay):
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=20*mm, rightMargin=20*mm,
                            topMargin=20*mm, bottomMargin=20*mm)
    styles = getSampleStyleSheet()
    title = ParagraphStyle("t", parent=styles["Heading1"], fontSize=15,
                           alignment=1, spaceAfter=2)
    sub = ParagraphStyle("s", parent=styles["Normal"], fontSize=11,
                         alignment=1, spaceAfter=10)
    elems = [Paragraph("STUDENT COURSE REGISTRATION &amp; RESULT PROCESSING SYSTEM", title),
             Paragraph("Official School Fees Receipt", sub)]

    st = pay.student
    rows = [
        ["Receipt No:", pay.gateway_ref or pay.invoice_no],
        ["Invoice No:", pay.invoice_no],
        ["Student:", f"{st.user.full_name} ({st.matric_no})"],
        ["Programme:", st.programme.name],
        ["Level:", f"{st.level} Level"],
        ["Session:", pay.session.name],
        ["Amount paid:", f"NGN {pay.amount:,.2f}"],
        ["Method:", (pay.method or "—").title()],
        ["Status:", pay.status.upper()],
        ["Paid at:", pay.paid_at.strftime("%Y-%m-%d %H:%M") if pay.paid_at else "—"],
    ]
    t = Table(rows, colWidths=[40*mm, 130*mm])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dbe4f0")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    elems += [t, Spacer(1, 10*mm),
              Paragraph("This receipt was generated electronically and is valid without "
                        "a physical signature.", styles["Normal"])]
    doc.build(elems)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"Receipt_{st.matric_no}_{pay.session.name.replace('/', '')}.pdf",
                     mimetype="application/pdf")