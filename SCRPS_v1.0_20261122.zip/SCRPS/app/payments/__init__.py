from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.auth import role_required
from app.models import (db, audit, notify, invoice_no, fee_amount, Session, Payment,
                        FeeClearance, User)
from app.payments.gateway import charge
from app.payments.receipts import receipt_pdf

bp = Blueprint("payments", __name__, url_prefix="/payments")

METHODS = [("card", "Debit card"), ("transfer", "Bank transfer"), ("ussd", "USSD")]


@bp.route("/")
@login_required
@role_required("student")
def my_payments():
    st = current_user.student
    sess = Session.query.filter_by(is_current=True).first()
    if not sess:
        flash("No current session has been configured.", "error")
        return redirect(url_for("main.dashboard"))
    pay = Payment.query.filter_by(student_id=st.id, session_id=sess.id).first()
    cleared = FeeClearance.query.filter_by(student_id=st.id, session_id=sess.id).first()
    history = (Payment.query.filter_by(student_id=st.id)
               .order_by(Payment.id.desc()).all())
    return render_template("payments_student.html", sess=sess, pay=pay, cleared=cleared,
                           amount=fee_amount(st, sess), invoice=invoice_no(st, sess),
                           history=history)


@bp.route("/checkout")
@login_required
@role_required("student")
def checkout():
    st = current_user.student
    sess = Session.query.filter_by(is_current=True).first() or abort(404)
    if FeeClearance.query.filter_by(student_id=st.id, session_id=sess.id).first():
        flash("Your fees are already cleared for this session.", "success")
        return redirect(url_for(".my_payments"))
    return render_template("checkout.html", sess=sess, amount=fee_amount(st, sess),
                           invoice=invoice_no(st, sess), methods=METHODS)


@bp.route("/pay", methods=["POST"])
@login_required
@role_required("student")
def pay():
    st = current_user.student
    sess = Session.query.filter_by(is_current=True).first() or abort(404)
    if FeeClearance.query.filter_by(student_id=st.id, session_id=sess.id).first():
        flash("Your fees are already cleared for this session.", "success")
        return redirect(url_for(".my_payments"))

    method = request.form.get("method", "card")
    if method not in dict(METHODS):
        flash("Choose a valid payment method.", "error")
        return redirect(url_for(".checkout"))

    amount = fee_amount(st, sess)
    result = charge(st, sess, amount, method)
    if not result.ok:
        flash(f"Payment failed: {result.message}", "error")
        return redirect(url_for(".checkout"))

    p = Payment.query.filter_by(student_id=st.id, session_id=sess.id).first()
    if not p:
        p = Payment(student_id=st.id, session_id=sess.id, invoice_no=invoice_no(st, sess))
        db.session.add(p)
    p.amount = amount
    p.method = method
    p.gateway_ref = result.reference
    p.status = "confirmed"
    p.paid_at = datetime.utcnow()
    p.decided_by = current_user.id
    p.decided_at = p.paid_at

    if not FeeClearance.query.filter_by(student_id=st.id, session_id=sess.id).first():
        db.session.add(FeeClearance(student_id=st.id, session_id=sess.id,
                                    cleared_by=current_user.id))
    notify(st.user_id, "Payment successful",
           f"NGN {amount:,.0f} received for {sess.name}. Registration is now unlocked.",
           url_for("registration.register"))
    for officer in User.query.filter_by(role="bursary", active=True).all():
        notify(officer.id, "Payment received",
               f"{st.matric_no} — NGN {amount:,.0f} ({result.reference})",
               url_for(".transactions"))
    audit(current_user.id, "payment", "payment", None,
          f"{st.matric_no} {amount} {result.reference}")
    db.session.commit()
    flash("Payment successful. Your fees are cleared and registration is unlocked.", "success")
    return redirect(url_for(".receipt", pay_id=p.id))


@bp.route("/receipt/<int:pay_id>")
@login_required
def receipt(pay_id):
    p = db.session.get(Payment, pay_id) or abort(404)
    if current_user.role == "student" and p.student_id != current_user.student.id:
        abort(403)
    return render_template("receipt.html", p=p)


@bp.route("/receipt/<int:pay_id>/pdf")
@login_required
def receipt_download(pay_id):
    p = db.session.get(Payment, pay_id) or abort(404)
    if current_user.role == "student" and p.student_id != current_user.student.id:
        abort(403)
    return receipt_pdf(p)


@bp.route("/transactions")
@login_required
@role_required("bursary", "admin")
def transactions():
    pays = Payment.query.order_by(Payment.id.desc()).all()
    total = sum(p.amount for p in pays if p.status == "confirmed")
    return render_template("transactions.html", pays=pays, total=total)


@bp.route("/queue")
@login_required
@role_required("bursary", "admin")
def queue():
    return redirect(url_for(".transactions"))