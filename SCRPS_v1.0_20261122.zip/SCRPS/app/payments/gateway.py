"""Payment gateway adapter.

Sandbox mode approves every charge instantly so the system works offline.
To go live: implement charge() with Paystack / Flutterwave / Remita, verify the
transaction server-side, and return the provider reference. Nothing else in the
application needs to change.
"""
import uuid
from datetime import datetime
from flask import current_app


class GatewayResult:
    def __init__(self, ok, reference="", message=""):
        self.ok = ok
        self.reference = reference
        self.message = message


def charge(student, session, amount, method):
    mode = current_app.config.get("GATEWAY_MODE", "sandbox")
    if mode == "sandbox":
        reference = "SCRPS-" + uuid.uuid4().hex[:12].upper()
        return GatewayResult(True, reference, "Payment approved")
    # Live provider integration point.
    return GatewayResult(False, "", "Live gateway is not configured.")