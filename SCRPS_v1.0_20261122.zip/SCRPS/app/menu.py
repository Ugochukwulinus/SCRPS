from app.auth import is_adviser


def build_menu(user):
    role = user.role
    if role == "student":
        return [("Dashboard", "main.dashboard"),
                ("Course Registration", "registration.register"),
                ("Payments", "payments.my_payments"),
                ("My Results", "results.my_results")]
    if role in ("lecturer", "adviser"):
        items = [("Dashboard", "main.dashboard"), ("Score Entry", "results.my_courses")]
        if is_adviser(user):
            items.append(("Approve Registrations", "registration.approve_list"))
        return items
    if role == "hod":
        return [("Dashboard", "main.dashboard"),
                ("Approve Registrations", "registration.approve_list"),
                ("Review Results", "results.hod_list"),
                ("Session Processing", "results.processing")]
    if role == "bursary":
        return [("Dashboard", "main.dashboard"), ("Transactions", "payments.transactions")]
    if role == "admin":
        return [("Dashboard", "main.dashboard"), ("Administration", "admin.index"),
                ("Registrations", "admin.registrations_report"),
                ("Transactions", "payments.transactions"),
                ("Session Processing", "results.processing")]
    return [("Dashboard", "main.dashboard")]