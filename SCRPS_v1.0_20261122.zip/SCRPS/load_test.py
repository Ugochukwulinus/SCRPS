"""120 students registering simultaneously on a SEPARATE database.
Run: python load_test.py   (does not touch scrps.db)"""
import os
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from config import Config
from app import create_app
from app.models import (db, User, Student, Lecturer, Faculty, Department, Programme,
                        Course, Curriculum, CurriculumItem, Session, Semester,
                        FeeClearance, LevelAdviser, Registration, RegistrationCourse)

N = 120


class LoadConfig(Config):
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(tempfile.mkdtemp(), "load.db")
    WTF_CSRF_ENABLED = False


app = create_app(LoadConfig)
with app.app_context():
    db.create_all()
    fac = Faculty(code="SCI", name="Science"); db.session.add(fac); db.session.flush()
    dept = Department(code="CSC", name="CS", faculty_id=fac.id)
    db.session.add(dept); db.session.flush()
    prog = Programme(code="CSC", name="B.Sc CS", department_id=dept.id)
    db.session.add(prog); db.session.flush()
    ids = []
    for i in range(6):
        c = Course(code=f"CSC10{i}", title=f"Course {i}", units=3, department_id=dept.id)
        db.session.add(c); db.session.flush()
        ids.append(c.id)
    cur = Curriculum(programme_id=prog.id, entry_year=2026)
    db.session.add(cur); db.session.flush()
    for cid in ids:
        db.session.add(CurriculumItem(curriculum_id=cur.id, course_id=cid,
                                      level=100, semester=1))
    sess = Session(name="2026/2027", is_current=True)
    db.session.add(sess); db.session.flush()
    sem = Semester(session_id=sess.id, number=1, registration_open=True)
    db.session.add(sem); db.session.flush()
    lu = User(username="LEC", full_name="Lecturer", role="adviser")
    lu.set_password("pass1234"); db.session.add(lu); db.session.flush()
    lect = Lecturer(user_id=lu.id, staff_no="LEC", department_id=dept.id)
    db.session.add(lect); db.session.flush()
    db.session.add(LevelAdviser(lecturer_id=lect.id, programme_id=prog.id, level=100))
    for i in range(N):
        u = User(username=f"L{i:03d}", full_name=f"Load Student {i}", role="student")
        u.set_password("pass1234"); db.session.add(u); db.session.flush()
        s = Student(user_id=u.id, matric_no=f"L{i:03d}", programme_id=prog.id,
                    entry_year=2026, level=100)
        db.session.add(s); db.session.flush()
        db.session.add(FeeClearance(student_id=s.id, session_id=sess.id))
    db.session.commit()
    COURSE_IDS = ids


def register(i):
    c = app.test_client()
    c.post("/login", data={"username": f"L{i:03d}", "password": "pass1234"})
    for cid in COURSE_IDS:
        c.post(f"/register/add/{cid}")
    c.post(f"/register/add/{COURSE_IDS[0]}")   # deliberate duplicate: must fail safely
    c.post("/register/submit")
    return i


t0 = time.time()
with ThreadPoolExecutor(max_workers=16) as ex:
    list(ex.map(register, range(N)))
dt = time.time() - t0

with app.app_context():
    regs = Registration.query.count()
    rcs = RegistrationCourse.query.count()
    submitted = Registration.query.filter_by(status="submitted").count()
    dups = (db.session.query(RegistrationCourse.registration_id,
                             RegistrationCourse.course_id)
            .group_by(RegistrationCourse.registration_id, RegistrationCourse.course_id)
            .having(db.func.count() > 1).count())

print(f"\n{N} concurrent students in {dt:.1f}s ({N / dt:.0f} registrations/s)")
print(f"registrations={regs}  course_rows={rcs}  submitted={submitted}  duplicates={dups}")
assert regs == N and rcs == N * 6 and submitted == N and dups == 0
print("LOAD TEST PASSED: no lost writes, no duplicates, no crashes.\n")