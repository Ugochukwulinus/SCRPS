import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "scrps-offline-key-change-in-production")
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "scrps.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # "sandbox" = offline gateway simulator. Set to "live" and implement
    # app/payments/gateway.py when deploying a real provider.
    GATEWAY_MODE = os.environ.get("GATEWAY_MODE", "sandbox")
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024   # 5 MB upload cap (CSV imports)