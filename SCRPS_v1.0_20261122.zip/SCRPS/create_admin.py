"""Command-line superuser creation & recovery.
Usage:  python create_admin.py
- Creates a new admin if the username does not exist.
- If the username exists, promotes it to admin, reactivates it and resets its password.
"""
import getpass
from app import create_app
from app.models import db, User

app = create_app()


def main():
    print("SCRPS superuser tool")
    full_name = input("Administrator full name: ").strip()
    username = input("Username [admin]: ").strip() or "admin"
    password = getpass.getpass("Password (min 6 characters): ")
    confirm = getpass.getpass("Confirm password: ")

    if not full_name:
        print("ERROR: Full name is required.")
        return
    if len(password) < 6:
        print("ERROR: Password must be at least 6 characters.")
        return
    if password != confirm:
        print("ERROR: Passwords do not match.")
        return

    with app.app_context():
        user = User.query.filter_by(username=username).first()
        if user:
            user.full_name = full_name
            user.role = "admin"
            user.active = True
            user.set_password(password)
            print(f"OK: existing user '{username}' is now an active superuser "
                  f"with a new password.")
        else:
            user = User(username=username, full_name=full_name, role="admin")
            user.set_password(password)
            db.session.add(user)
            print(f"OK: superuser '{username}' created.")
        db.session.commit()


if __name__ == "__main__":
    main()